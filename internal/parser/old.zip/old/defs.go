// =================================================================================================
// Alex Peters - January 26, 2024
// =================================================================================================

package parser

import (
	"github.com/petersalex27/yew/common"
	"github.com/petersalex27/yew/token"
)

// use to collect a function definition but delay it until module is ready to be built
func (parser *Parser) DefineFunctionLater(def FunctionDefinition) {
	// match pattern against all known forward declarations of the file
	if cap(parser.Functions) == 0 {
		parser.Functions = []FunctionDefinition{def}
		return
	}

	parser.Functions = append(parser.Functions, def)
}

func (parser expressionParser) parseDefPattern() (pat []PatternNode, ok bool) {
	pat = []PatternNode{}
	for again := true; again; {
		again = parser.parseDefPatternIteration(&pat)
	}
	return pat, !parser.panicking
}

func (parser expressionParser) parseDefPatternIteration(pat *[]PatternNode) (again bool) {
	switch parser.Peek().Type {
	case token.Affixed:
		fallthrough
	case token.Id:
		again = parser.parseDefPatternIdent(pat)
	case token.CapId:
		again = parser.parseDefPatternKindIdent(pat)
	case token.IntValue:
		fallthrough
	case token.CharValue:
		fallthrough
	case token.StringValue:
		fallthrough
	case token.FloatValue:
		again = parser.parseDefPatternConstant(pat)
	case token.LeftParen:
		again = parser.parseDefPatternParenthesized(pat)
	case token.LeftBracket:
		again = parser.parseDefPatternList(pat)
	}
	return
}

func (parser expressionParser) parseDefPatternConstant(pat *[]PatternNode) (ok bool) {
	var constant Constant
	constant, ok = Constant{parser.Advance()}, true
	*pat = append(*pat, constant)
	return
}

func (parser expressionParser) parseDefPatternIdent(pat *[]PatternNode) (ok bool) {
	var ident Ident
	if ident, ok = parser.parseFunctionName(); ok {
		*pat = append(*pat, ident)
	}
	return
}

func (parser expressionParser) parseDefPatternKindIdent(pat *[]PatternNode) (ok bool) {
	var ident KindIdent
	if ident.Token, ok = parser.capIdToken(); ok {
		*pat = append(*pat, ident)
	}
	return
}

func (parser expressionParser) parseDefPatternList(pat *[]PatternNode) (ok bool) {
	var ls List
	start := parser.Advance().Start
	if ls, ok = parser.parseList(start); ok {
		*pat = append(*pat, ls)
	}
	return
}

func (parser expressionParser) parseDefPatternParenthesized(pat *[]PatternNode) (ok bool) {
	var p PatternNode
	start := parser.Advance().Start
	if p, ok = parser.parseEnclosed(start); ok {
		*pat = append(*pat, p)
	}
	return
}

func (parser *Parser) parseDefinition() (end bool) {
	var ok bool
	switch parser.Peek().Type {
	case token.LeftParen:
		ok = parser.parseEnclosedAnnotation()
	case token.At:
		ok = parser.parseAnnotation()
	case token.Id:
		fallthrough
	case token.Affixed:
		ok = parser.parseFunction()
	case token.CapId:
		ok = parser.parseTypeDef()
	case token.Trait:
		ok = parser.parseTraitDef()
	case token.Alias:
		ok = parser.parseTypeAliasDef()
	default:
		// nothing
	}

	return !ok
}

func (parser *Parser) parseDefinitions() (ok bool) {
	var end bool
	for !end {
		parser.dropDroppables()
		end = parser.parseDefinition()
	}

	return !parser.panicking
}

// parses a forward declaration of a function
//
// ASSUMPTION: next token is a colon (':') and identifier has already been parsed
func (parser *Parser) parseForwardDeclaration(ident Ident) (ok bool) {
	annots := parser.annotate() // possibly empty
	parser.Advance()            // advance past ':'
	var ty TypeNode
	ty, ok = parser.parseType()
	if !ok {
		return
	}
	_, ok = parser.Declare(annots, ident, ty)
	return
}

// 0 or more idents may already be parsed and passed as an argument to this function. If no args are
// given, then this function will attempt to parse at least one identifier, failing if it cannot.
//
// if more idents are to be parsed, then this function expects the next token to be a comma (',').
// Next token here refers to either to next token on function entry if more than zero idents are
// passed as args, otherwise it refers to the next token after parsing the first identifier.
//
// no errors will be recorded if a comma is not found, however.
//
// The type that is parsed will be given to all collected identifiers.
func (parser *Parser) parseForwardDeclarationList(idents ...Ident) ([]Ident, TypeNode, bool) {
	var ident Ident
	var ok bool
	if len(idents) == 0 {
		// get first ident
		if ident, ok = parser.parseFunctionName(); !ok {
			return nil, TupleType{}, ok
		}
		idents = []Ident{ident}
	}

	for parser.Peek().Type == token.Comma {
		_ = parser.Advance() // advance past comma token
		ident, ok = parser.parseFunctionName()
		if !ok {
			return nil, TupleType{}, ok
		}
		idents = append(idents, ident)
	}

	if _, ok = parser.colonToken(); !ok {
		return nil, TupleType{}, ok
	}

	var ty TypeNode
	if ty, ok = parser.parseType(); !ok {
		return nil, TupleType{}, ok
	}

	// declare all parsed idents
	return idents, ty, ok
}

func (parser *Parser) parseAndDeclareForwardDeclarationList(idents ...Ident) (ok bool) {
	var ids []Ident
	var ty TypeNode
	ids, ty, ok = parser.parseForwardDeclarationList(idents...)
	if ok {
		return parser.declareForwardDeclarationList(ty, ids...)
	}
	return
}

// does preliminary declaration part after declarations have been parsed
func (parser *Parser) declareForwardDeclarationList(ty TypeNode, idents ...Ident) (ok bool) {
	annots := parser.annotate() // possibly nothing returned
	// declare all parsed idents
	for _, id := range idents {
		_, ok = parser.Declare(annots, id, ty)
		if !ok {
			return
		}
	}
	return
}

// parses function definition or function forward declaration
func (parser *Parser) parseFunction() (ok bool) {
	// TODO: add a cleaned-up version of this to the Yew manual
	/*
			affixed functions must be forward declared

			here a valid example, if-then-else:
				-- forward declaration, then definition
				if_then_else_ : Bool -> a -> a -> a
				if True then action else _ = action
				if False then _ else action = action

			here is an invalid (if you planned on defining an affixed function) example for if-then-else:
				if True then action else _ = action
				if False then _ else action = action

			here's another invalid example:
				if_then_else_ : Bool -> a -> a -> a
				if_then_else_ True action _ = action
				if_then_else_ False _ action = action
			Why is the above invalid?: cannot always tell the difference between an affixed id being used as
		  a param pattern for an affixed identifier and an affixed id being used as the name

			here's an example that makes that clearer:
				_+_ f x
			is this saying `_+_` has the params `f` and `x` or `f` is `_f_` and has the params `_+_` and x?

			The invalid example would be defined as a function:
				if : Bool -> a -> b -> c -> b = b
	*/

	var ident Ident
	if ident, ok = parser.parseFunctionName(); !ok {
		return
	}

	if parser.Peek().Type == token.Comma {
		return parser.parseAndDeclareForwardDeclarationList(ident)
	}

	if parser.Peek().Type == token.Colon {
		return parser.parseForwardDeclaration(ident)
	}

	var def FunctionDefinition
	def, ok = parser.parseFunctionWithName(ident)
	parser.DefineFunctionLater(def)
	return
}

func (parser *Parser) parseFunctionWithName(ident Ident) (function FunctionDefinition, ok bool) {
	// get tail part of pattern
	var pat []PatternNode
	if parser.Peek().Type != token.Equal {
		patternParser := parser.ForPattern()
		if pat, ok = patternParser.parseDefPattern(); ok {
			pat = common.Prepend(PatternNode(ident), pat)
		}
	} else {
		pat, ok = []PatternNode{ident}, true
	}

	if !ok {
		return
	}

	function = FunctionDefinition{
		definitionNumber: parser.AdvanceDefNumber(),
		Pattern:          pat,
	}

	if _, ok = parser.equalToken(); !ok {
		return
	}

	parser.dropDroppables()

	function.Assignment, ok = parser.ForExpr().parseExpression()
	return
}

func (trait *TraitDefinition) attachForwardDeclarations(idents []Ident, ty TypeNode) {
	for _, ident := range idents {
		dec := DeclarationMake(ident, ty)
		trait.Declarations = append(trait.Declarations, dec)
	}
}

// parses trait definition
//
// assumes 'trait' token is at parser.Next
func (parser *Parser) parseTraitDef() (ok bool) {
	start := parser.Advance().Start // advance past `trait` keyword and grab start pos

	var traitDef TraitDefinition
	var env Environment

	ok = true
	parseEnv := parser.HasEnvironment()
	if parseEnv {
		env, ok = parser.parseTypeEnvironment()
	}

	if !ok {
		return
	}

	if traitDef, ok = parser.parseTraitName(); !ok {
		return
	}

	// attach (possibly empty) environment
	traitDef.Environment = env
	// set start position
	traitDef.Start = start

	if _, ok = parser.whereToken(); !ok {
		return
	}

	traitDef.Declarations = []Declaration{}

	parser.dropDroppables()
	for again := true; again; {
		var idents []Ident
		var ty TypeNode
		idents, ty, ok = parser.parseForwardDeclarationList()
		if !ok {
			return
		}
		traitDef.attachForwardDeclarations(idents, ty) // declare
		parser.dropDroppables()
		next := parser.Peek().Type
		again = next == token.Id || next == token.Affixed
	}

	// read 'end' token
	var endTok token.Token
	endTok, ok = parser.endToken()
	if !ok {
		return
	}

	traitDef.End = endTok.End
	parser.DeclareTrait(traitDef)
	// define trait
	parser.module.Define(traitDef.Name.Name.Token, traitDef)
	return
}

var condition = map[token.Type]map[token.Type]struct{}{
	token.Comma: {
		token.CapId:      {},
		token.RightParen: {},
	},
	token.CapId: {
		token.Id: {},
	},
	token.Id: {
		token.Id:         {},
		token.Comma:      {},
		token.RightParen: {},
	},
}

func (parser *Parser) HasEnvironment() bool {
	save := parser.tokenPos
	// reset token position at the end
	defer func() { parser.tokenPos = save }()

	enclosed := parser.Peek().Type == token.LeftParen
	if enclosed {
		_ = parser.Advance()
	}

	if parser.Peek().Type != token.CapId {
		return false
	}

	var m map[token.Type]struct{} = condition[token.CapId]

	var previous token.Type = token.EndOfTokens // sentinel starting value

	var found, ok bool
	for found {
		_, found = m[parser.Peek().Type] // these are the elements that must be found ...
		ok = found                       // ... hence, assign ok the value of found
		if found {
			previous = parser.Peek().Type
			_ = parser.Advance()
			// these are the elements that do not need to be found b/c the signify the end
			// of valid input (sometimes)
			m, found = condition[previous] // not found on rparen
		}
	}

	if ok && enclosed {
		ok = previous == token.RightParen
	}

	return ok && parser.Peek().Type == token.ThickArrow
}

func (parser *Parser) parseTraitName() (traitDef TraitDefinition, ok bool) {
	traitDef.Name, ok = parser.parseTrait()
	return
}

// parses type alias definition
func (parser *Parser) parseTypeAliasDef() (ok bool) {
	start := parser.Advance().Start // advance past alias keyword

	alias := AliasDefinition{}
	alias.Start = start

	if alias.Alias, ok = parser.parseTypeConstant(); !ok {
		return
	}

	if _, ok = parser.equalToken(); !ok {
		return
	}

	parser.dropDroppables()
	alias.Aliased, ok = parser.parseParameterizedTypeLike()
	alias.End = alias.Aliased.End
	// declare
	if ok = parser.DeclareAlias(alias.Alias, alias.Aliased.Name); !ok {
		return
	}
	// define alias
	name := alias.Alias.Token
	parser.module.Define(name, alias)
	return
}

func (parser *Parser) parseConstructorMaybeEnclosed() (c TypeConstructor, ok bool) {
	if parser.Peek().Type != token.LeftParen {
		return parser.parseConstructor()
	}

	start := parser.Advance().Start
	c, ok = parser.parseConstructorMaybeEnclosed()
	if !ok {
		return
	}
	var rparen token.Token
	if rparen, ok = parser.rightParenToken(); !ok {
		return
	}
	c.Start = start
	c.End = rparen.End
	return
}

func (parser *Parser) parseConstructor() (c TypeConstructor, ok bool) {
	var constructorName TypeConstant
	if constructorName, ok = parser.parseTypeConstant(); !ok {
		return
	}
	var app TypeApplication 
	app, ok = parser.parseTypeApplicationMaybeSingle(constructorName)
	if !ok {
		return
	}
	c.Params = app.Elems[1:] // remove name
	c.Name = KindIdent(constructorName)
	return
}

// parses type definition
func (parser *Parser) parseTypeDef() (ok bool) {
	typeDef := TypeDefinition{}
	typeDef.Type, ok = parser.parseParameterizedTypeLike()
	if !ok {
		return
	}

	typeDef.Start = typeDef.Type.Start
	if ok = parser.DeclareType(typeDef.Type); !ok {
		return
	}

	if _, ok = parser.equalToken(); !ok {
		return
	}

	typeDef.Constructors = []TypeConstructor{}
	var cons TypeConstructor
	for again := true; again; {
		parser.dropDroppables()
		cons, ok = parser.parseConstructorMaybeEnclosed()
		if !ok {
			return
		}
		parser.dropDroppables()
		typeDef.Constructors = append(typeDef.Constructors, cons)
		if again = parser.Peek().Type == token.Bar; again {
			_, ok = parser.barToken()
			again = ok
		}
	}

	if ok = !parser.panicking; !ok {
		return
	}

	typeDef.End = typeDef.Constructors[len(typeDef.Constructors)-1].End
	name := typeDef.Type.Name.Token
	parser.module.Define(name, typeDef)
	return
}

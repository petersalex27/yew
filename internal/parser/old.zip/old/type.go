// =================================================================================================
// Alex Peters - January 27, 2024
//
// Parses a type
// =================================================================================================
package parser

import (
	"github.com/petersalex27/yew/common/stack"
	"github.com/petersalex27/yew/token"
	"github.com/petersalex27/yew/types"
)

// parses arrow type
//
// arrow is right-to-left associative, i.e.,
//
//	a -> b -> c == a -> (b -> c)
func (parser *Parser) parseArrowType(lhs TypeNode) (arrowType ArrowType, done, ok bool) {
	arrowType.Types = []TypeNode{lhs}
	var rhs TypeNode
	var again bool = true
	for again && !done {
		if _, ok = parser.arrowToken(); !ok {
			return
		}
		rhs, again = parser.parseTypeIteration()
		if again {
			arrowType.Types = append(arrowType.Types, rhs)
			done = parser.Peek().Type != token.Arrow
		} // else done must still be false here, this will tell caller to look for a dependent type
	}

	// caller of this function will catch any dependent type
	_, arrowType.End = rhs.Pos()
	arrowType.Start, _ = lhs.Pos()
	return
}

func (parser *Parser) parseFunctionType(lhs TypeNode) (functionType FunctionType, ok bool) {
	var arrowType ArrowType
	var done bool
	arrowType, done, ok = parser.parseArrowType(lhs)
	if !ok {
		return
	}
	if done {
		return arrowType, ok
	}

	// not done, expect dependent function type

	next := parser.Peek()
	isDependentType := (next.Type == token.Id && next.Value == "*") || (next.Type == token.LeftBrace)
	if ok = isDependentType; !ok {
		parser.error(UnexpectedToken)
		return
	}

	dep := DependentFunctionType{
		Start:      arrowType.Start,
		FirstOrder: arrowType.Types,
	}
	dep.SecondOrder, ok = parser.parseTypeFamily()
	return dep, ok
}

func (parser *Parser) parseJudgmentType(start int, t TypeNode) (vj VarJudgment, ok bool) {
	// un-enclose parenthesized type
	var t2 ParenType
	for t2, ok = t.(ParenType); ok; {
		t = t2.TypeNode
		t2, ok = t.(ParenType)
	}

	// check t is type variable (this is true iff an ident was parsed)
	var tv TypeVariable
	if tv, ok = t.(TypeVariable); !ok {
		s, e := t.Pos()
		parser.error2(ExpectedVariable, s, e)
		return
	}

	vj.Ident = Ident{tv.Token}
	vj.TypeNode, ok = parser.parseType()
	if !ok {
		return
	}

	var rparen token.Token
	if rparen, ok = parser.rightParenToken(); !ok {
		return
	}

	vj.Start = start
	vj.End = rparen.End
	return
}

func (parser *Parser) parseListType() (ty ListType, ok bool) {
	if parser.Peek().Type != token.LeftBracket {
		panic("bug: input not validated")
	}

	var lbrack, rbrack token.Token
	lbrack = parser.Advance()

	ty.Elem, ok = parser.parseType()
	if !ok && !parser.Panicking() {
		// read nothing, basically
		parser.error(InvalidListElementType)
		return
	}

	if rbrack, ok = parser.rightBracketToken(); !ok {
		return
	}

	ty.Start, ty.End = lbrack.Start, rbrack.End
	return
}

func (parser *Parser) parseParams() (params []TypeVariable, ok bool) {
	params = []TypeVariable{}
	for parser.Peek().Type == token.Id {
		var v TypeVariable
		v, ok = parser.parseTypeVariable()
		params = append(params, v)
	}
	return
}

// parses paren enclosed parameterized type
func (parser *Parser) parseParameterizedParenEnclosed() (ty ParameterizedTypeLike, ok bool) {
	start := parser.Advance().Start
	ty, ok = parser.parseParameterizedTypeLike()
	if !ok {
		return
	}
	var rparen token.Token
	if rparen, ok = parser.rightParenToken(); ok {
		ty.Start = start
		ty.End = rparen.End
	}
	return
}

// parses parameterized type (may be paren enclosed)
func (parser *Parser) parseParameterizedTypeLike() (ty ParameterizedTypeLike, ok bool) {
	if parser.Peek().Type == token.LeftParen {
		return parser.parseParameterizedParenEnclosed()
	}

	if ty.Name, ok = parser.parseTypeConstant(); !ok {
		return
	}
	ty.Params, ok = parser.parseParams()
	return
}

func (parser *Parser) parseParenType() (ty TypeNode, ok bool) {
	if parser.Peek().Type != token.LeftParen {
		panic("bug: input not validated")
	}

	var pt ParenType

	lparen := parser.Advance() // advance past left parenthesis '('

	if pt.TypeNode, ok = parser.parseType(); !ok {
		return
	}

	if parser.Peek().Type == token.Comma {
		return parser.parseTupleType(lparen.Start, pt.TypeNode)
	} else if parser.Peek().Type == token.Colon {
		return parser.parseJudgmentType(lparen.Start, pt.TypeNode)
	}

	var rparen token.Token
	if rparen, ok = parser.rightParenToken(); !ok {
		return
	}

	pt.Start, pt.End = lparen.Start, rparen.End
	return pt, ok
}

func (parser *Parser) parseTupleType(start int, first TypeNode) (ty TupleType, ok bool) {
	if parser.Peek().Type != token.Comma {
		panic("bug: input not validated")
	}

	ty.Elems = []TypeNode{first}

	again := true
	for again {
		_ = parser.Advance() // advance past comma

		if parser.Peek().Type == token.RightParen {
			// comma ended tuple, e.g., (Int, Bool,). This is fine: exit loop
			break
		}

		var elem TypeNode
		if elem, ok = parser.parseType(); !ok {
			return
		}
		ty.Elems = append(ty.Elems, elem)

		next := parser.Peek().Type
		again = next == token.Comma
	}

	if ok = len(ty.Elems) >= 2; !ok {
		parser.error(IllegalTupleType)
		return
	}

	var rparen token.Token
	if rparen, ok = parser.rightParenToken(); !ok {
		return
	}

	ty.Start, ty.End = start, rparen.End
	return
}

func (parser *Parser) parseTypeApplication(first TypeNode) (ty TypeApplication, ok bool) {
	var ty2 TypeNode
	ty2, ok = parser.parseTypeApplicationMaybeSingle(first)
	if !ok {
		return
	}
	if ty, ok = ty2.(TypeApplication); !ok {
		parser.error(ExpectedTypeApplication) // not sure how this would ever come about tbh
	}

	if ok = len(ty.Elems) > 1; !ok {
		parser.error(ExpectedTypeApplication) // not sure how this would ever come about tbh
		return
	}

	ty.Start, _ = first.Pos()
	_, ty.End = ty.Elems[len(ty.Elems)-1].Pos()
	return
}

func (parser *Parser) parseTypeApplicationMaybeSingle(first TypeNode) (ty TypeApplication, ok bool) {
	ty.Elems = []TypeNode{first}
	ok = true
	for ok { // apply types
		var elem TypeNode
		elem, ok = parser.parseTypeIteration()
		if ok {
			ty.Elems = append(ty.Elems, elem)
		}
	}

	if ok = !parser.panicking; !ok {
		return
	}

	ty.Start, _ = first.Pos()
	_, ty.End = ty.Elems[len(ty.Elems)-1].Pos()
	return
}

// parses the following
//
// T a .. b =>
// (T a .. b) =>
// (T a .. b, .., U c .. d) =>
func (parser *Parser) parseTypeEnvironment() (env Environment, ok bool) {
	endWithParen := parser.Peek().Type == token.LeftParen
	if endWithParen {
		env.Start = parser.Advance().Start
	}

	env.Traits = []Trait{}

	for again := true; again; {
		again = parser.parseTypeEnvironmentIteration(&env, endWithParen)
	}

	if ok = !parser.panicking; !ok {
		return
	}

	if endWithParen {
		if _, ok = parser.rightParenToken(); !ok {
			return // bad input, expected rparen
		}
	}

	var thickArrow token.Token
	if thickArrow, ok = parser.thickArrowToken(); !ok {
		return
	}

	env.End = thickArrow.End
	return
}

func (parser *Parser) parseTypeEnvironmentIteration(env *Environment, endWithParen bool) (again bool) {
	var trait Trait
	if trait, again = parser.parseTrait(); !again {
		return
	}
	env.Traits = append(env.Traits, trait)
	// commas are not legal in non-parenthesis enclosed environments
	again = endWithParen && parser.Peek().Type == token.Comma
	if again { // implicitly, this branch is only accessible if env is enclosed w/in parens
		// check if comma is trailing comma or denotes a continued env tuple
		_ = parser.Advance()
		again = parser.Peek().Type == token.CapId
	}
	return
}

func (parser *Parser) parseTypeConstant() (ty TypeConstant, ok bool) {
	ty.Token, ok = parser.capIdToken()
	return
}

func (parser *Parser) parseTypeVariable() (ty TypeVariable, ok bool) {
	var v token.Token
	if v, ok = parser.variableIdToken(); !ok {
		return
	}

	ty.Token = v
	return
}

func (parser *Parser) parseTyp() {
	const (
		arrowPrec uint8 = 1
		colonPrec uint8 = 2
		commaPrec uint8 = 0
	)
	s := stack.NewStack[types.Type](8)
	var precedence uint8 = 0

	for {
		next := parser.Peek()
		switch next.Type {
		case token.Id:
			if next.Value == "*" {
				s.Push(types.Constant(next.Value))
			} else {
				s.Push(types.Variable(next.Value))
			}
		case token.CapId:
			s.Push(types.Constant(next.Value))
		case token.LeftParen:
		case token.LeftBracket:
		case token.Arrow:
			if precedence > arrowPrec {
				
			}
		}
	}
}

func (parser *Parser) parseType() (ty TypeNode, ok bool) {
	ty, ok = parser.parseTypeIteration()
	next := parser.Peek()
	switch next.Type {
	case token.Id:
		fallthrough
	case token.CapId:
		fallthrough
	case token.LeftParen:
		fallthrough
	case token.LeftBracket:
		ty, ok = parser.parseTypeApplication(ty)
		if !ok {
			return
		}
		if parser.Peek().Type != token.Arrow {
			return
		}
		fallthrough
	case token.Arrow:
		return parser.parseFunctionType(ty)
	}
	return
}

func (parser *Parser) parseTypeFamily() (family TypeFamily, ok bool) {
	next := parser.Peek()
	switch next.Type {
	case token.Id:
		if next.Value != "*" {
			panic("illegal argument, input was not validated")
		}
		family.isAny = true
		family.Start, family.End = next.Start, next.End
		ok = true
	case token.LeftBrace:
		save := parser.isParsingFamily
		parser.isParsingFamily = true
		start := parser.Advance().Start
		family, ok = parser.parseTypeFamilyEnclosed(start)
		parser.isParsingFamily = save
	}

	// prioritize a general syntax error over the very specific error of illegal enclosed dep. type
	//  - hard to validate that already erroneous input is meant to be a dependent type
	//	- give this error, and once corrected, if source was actually dep. type, then it will fail
	//		on that compilation too.
	if !ok {
		return
	}

	// this is here because need to make sure the first token was not just an erroneous "{"
	if ok = !parser.isParsingFamily; !ok {
		parser.error2(IllegalEnclosedTypeFamily, family.Start, family.End)
		return
	}
	return
}

func (parser *Parser) parseTypeFamilyEnclosed(start int) (family TypeFamily, ok bool) {
	family.isAny = false
	family.Start = start
	family.Elems = []TypeNode{}
	var ty TypeNode
	var again bool = true
	for again {
		ty, ok = parser.parseType()
		if !ok {
			return
		}

		family.Elems = append(family.Elems, ty)

		again = parser.Peek().Type == token.Bar
		if again {
			_ = parser.Advance()
		}
	}

	var rbrace token.Token
	if rbrace, ok = parser.rightBraceToken(); !ok {
		return
	}
	family.End = rbrace.End
	return
}

func (parser *Parser) parseTypeIteration() (ty TypeNode, ok bool) {
	next := parser.Peek()
	switch next.Type {
	case token.LeftParen:
		ty, ok = parser.parseParenType()
	case token.LeftBracket:
		ty, ok = parser.parseListType()
	}

	if ok {
		return
	}

	ty, ok = parser.parseTypeIterationInitial()
	if !ok {
		return
	}

	app := &TypeApplication{Elems: []TypeNode{ty}}
	for ok {
		ok = parser.parseTypeIterationApp(app)
	}

	return app, ok
}

func (parser *Parser) parseTypeIterationInitial() (ty TypeNode, ok bool) {
	next := parser.Peek()
	switch next.Type {
	case token.Id:
		if next.Value == "*" {
			return
		}
		ty, ok = parser.parseTypeVariable()
	case token.CapId:
		ty, ok = parser.parseTypeConstant()
	}
	return
}

func (parser *Parser) parseTypeIterationApp(applyTo *TypeApplication) (ok bool) {
	next := parser.Peek()
	var ty TypeNode
	switch next.Type {
	case token.Id:
		if next.Value == "*" {
			break
		}
		ty, ok = parser.parseTypeVariable()
	case token.CapId:
		ty, ok = parser.parseTypeConstant()
	case token.LeftParen:
		ty, ok = parser.parseParenType()
	case token.LeftBracket:
		ty, ok = parser.parseListType()
	}

	if ok {
		applyTo.Elems = append(applyTo.Elems, ty)
	}

	return
}

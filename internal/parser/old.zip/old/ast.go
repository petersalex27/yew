// =================================================================================================
// Alex Peters - January 24, 2024
//
// Type definitions and methods for Ast nodes
// =================================================================================================

package parser

import (
	"github.com/petersalex27/yew/common"
	"github.com/petersalex27/yew/module"
	"github.com/petersalex27/yew/token"
	"github.com/petersalex27/yew/types"
)

// all nodes implement this
type Node interface {
	Pos() (start, end int)
	Visit(parser *Parser) (en ExprNode, ok bool)
	common.PrettyPrintable
}

// all expression nodes implement this
type ExprNode interface {
	Node
	exprNode()
	Action(parser *Parser) (ok bool)
	Substitute(*common.Table[Ident, ExprNode]) ExprNode
	Match(*common.Table[Ident, ExprNode]) ExprNode
}

type ListLike = struct {
	Start, End int
	Elems      []ExprNode
}

// all pattern nodes implement this
type PatternNode interface {
	Node
	ExprNode
	patternNode()
}

// all type nodes implement this
type TypeNode interface {
	Node
	typeNode()
	ToType() types.Type
}

type FunctionType interface {
	// true if declaration takes the form of a non-constant dependent type
	//
	// NOTE: a true return value does not actually entail the type is a non-constant dependent type,
	// it only says something about the way in which it was declared
	//
	// example for note:
	//	myConstType : a -> *
	//	myConstType _ = Int
	StrictlyDepType() bool
	TypeNode
}

type ParameterizedTypeLike = struct {
	Start, End int
	Name       TypeConstant
	Params     []TypeVariable
}

type TypeTupleLike = struct {
	Start, End int
	Elems      []TypeNode
}

type DefinitionType byte

const (
	FunctionDef DefinitionType = iota
	TypeDef
	TraitDef
	AliasDef
)

type DefinitionNode interface {
	Node
	definitionNode()
}

type DefinedModuleFunction struct {
	Declaration        *Declaration
	FunctionDefinition FunctionDefinition
}

type (
	// alias Int = Int64
	AliasDefinition struct {
		Start, End int
		Alias      TypeConstant
		Aliased    ParameterizedTypeLike
	}

	// @test
	Annotation struct {
		Start, End int
		Name       token.Token
		Args       []Node
	}

	// x y
	Application ListLike

	// a -> b
	ArrowType struct {
		Start, End int
		Types      []TypeNode
	}

	// 1
	Constant struct {
		token.Token
	}

	// (T a, U b) =>
	Environment struct {
		Start, End int
		Traits     []Trait
	}

	// represents the source file, things defined here but not w/in a module cannot be exported
	File struct {
		Start, End int
		Path       string
	}

	// map: (a -> b) -> f a -> f b
	Declaration struct {
		Annotations []Annotation
		Split       []string
		Ident       Ident
		Environment Environment
		TypeNode    TypeNode
	}

	DependentFunctionType struct {
		Start, End  int
		FirstOrder  []TypeNode
		SecondOrder TypeFamily
	}

	FunctionDefinition struct {
		Start, End       int
		definitionNumber int
		Name             Ident
		// the pattern must match the order it appears in in the source code.
		// lots of functions/methods make this assumption when accessing this
		Pattern    []PatternNode
		Assignment ExprNode
	}

	// x
	Ident module.Ident

	// import math
	Import struct {
		// Start is the start position of 'import'
		Start int
		// End is the end position of 'in'
		End int
		// (accessor name, module lookup name)
		*common.Table[token.Token, token.Token]
	}

	// Just
	KindIdent struct {
		token.Token
	}

	// (\x -> x)
	Lambda struct {
		Start, End int
		uid        Ident
		Binders    []Ident
		Bound      ExprNode
	}

	LetBinding struct {
		Start, End int
		Bindings   []FunctionDefinition
		Bound      ExprNode
	}

	// [1, 2, 3]
	List ListLike

	// [Type]
	ListType struct {
		Start, End int
		Elem       TypeNode
	}

	// module main where { ...
	Module struct {
		Import      Import
		Use         Use
		Start, End  int
		ModuleName  token.Token
		Definitions *common.Table[token.Token, []DefinitionNode]
	}

	// (e)
	ParenExpr struct {
		Start, End int
		ExprNode
	}

	// (Type)
	ParenType struct {
		Start, End int
		TypeNode
	}

	Trait ParameterizedTypeLike

	TraitDefinition struct {
		Start, End   int
		Annotation   *Annotation
		Environment  Environment
		Name         Trait
		Declarations []Declaration
	}

	TupleKind ListLike

	// (Int, Char, Bool)
	TupleType TypeTupleLike

	TypeApplication TypeTupleLike

	// Int
	TypeConstant struct {
		token.Token
	}

	TypeConstructor struct {
		Start, End int
		Name       KindIdent
		Params     []TypeNode
	}

	TypeDefinition struct {
		Start, End   int
		Type         ParameterizedTypeLike
		Constructors []TypeConstructor
	}

	TypeFamily struct {
		Start, End int
		isAny      bool
		Elems      []TypeNode
	}

	// x: Int
	TypeJudgment struct {
		ExprNode
		TypeNode
	}

	// a
	TypeVariable module.TypeVariable

	// use ... in
	Use struct {
		Start, End int
		// (accessor name, module lookup name)
		*common.Table[token.Token, token.Token]
	}

	VarJudgment struct {
		Start, End int
		Ident      Ident
		TypeNode   TypeNode
	}
)

// Match implements ExprNode.
func (a Application) Match(*common.Table[Ident, ExprNode]) ExprNode {
	panic("unimplemented")
}

func (vj VarJudgment) Pos() (start, end int) {
	return vj.Start, vj.End
}

func (vj VarJudgment) PrettyPrint(p *common.SourcePrinter) {
	p.WriteByte('(')
	vj.Ident.PrettyPrint(p)
	p.WriteString(" : ")
	vj.TypeNode.PrettyPrint(p)
	p.WriteByte(')')
}

func (vj VarJudgment) ToType() types.Type {
	return vj.TypeNode.ToType()
}

func (vj VarJudgment) Visit(parser *Parser) (e ExprNode, ok bool) {
	ok = true
	return
}

func (dep DependentFunctionType) Pos() (start int, end int) {
	return dep.Start, dep.End
}

func (dep DependentFunctionType) PrettyPrint(p *common.SourcePrinter) {
	for _, ty := range dep.FirstOrder {
		ty.PrettyPrint(p)
		p.WriteString(" -> ")
	}

	dep.SecondOrder.PrettyPrint(p)
}

func (dep DependentFunctionType) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (family TypeFamily) PrettyPrint(p *common.SourcePrinter) {
	if family.isAny {
		p.WriteByte('*')
		return
	}

	p.WriteByte('{')
	defer p.WriteByte('}')

	length := len(family.Elems)
	if length == 0 {
		return
	}

	for _, elem := range family.Elems[:length-1] {
		elem.PrettyPrint(p)
		p.WriteString(" | ")
	}
	family.Elems[length-1].PrettyPrint(p)
}

// attempts to identify pattern by its first element (fails if there is no first element)
//
// returns the identifier and true on success, else the zero value of `Ident` and false
func AttemptIdentification(pattern []PatternNode) (ident Ident, success bool) {
	if len(pattern) < 1 {
		return
	}

	first := pattern[0]
	if _, success = first.(Ident); !success {
		return
	}
	ident = first.(Ident)
	return
}

func (module *Module) Define(name token.Token, def DefinitionNode) {
	defs, found := module.Definitions.Find(name)
	if !found {
		defs = []DefinitionNode{def}
	} else {
		defs = append(defs, def)
	}
	module.Definitions.Map(name, defs)
}

func (e Environment) IsEmpty() bool {
	return len(e.Traits) == 0
}

func (a Application) Action(parser *Parser) (ok bool) {
	parser.shift(a)
	return true
}

func (c Constant) Action(parser *Parser) (ok bool) {
	parser.shift(c)
	return true
}

func (ident Ident) Action(parser *Parser) (ok bool) {
	return parser.hold(ident)
}

func (kind KindIdent) Action(parser *Parser) (ok bool) {
	panic("TODO: implement")
	// TODO: implement
}

func (lambda Lambda) Action(parser *Parser) (ok bool) {
	var en ExprNode
	en, ok = lambda.Visit(parser)
	if !ok {
		return
	} // a && not b
	return
}

func (LetBinding) Action(parser *Parser) (ok bool) { return }

func (List) Action(parser *Parser) (ok bool) { return }

func (ParenExpr) Action(parser *Parser) (ok bool) { return }

func (TupleKind) Action(parser *Parser) (ok bool) { return }

func (alias AliasDefinition) PrettyPrint(p *common.SourcePrinter) {
	p.WriteString("alias ")
	alias.Alias.PrettyPrint(p)
	p.WriteString(" = ")
	alias.Aliased.Name.PrettyPrint(p)
	common.PrettyPrintPrintables(p, alias.Aliased.Params, " ")
}

// annotations aren't recorded, at least for now
func (a Annotation) PrettyPrint(*common.SourcePrinter) {}

func (a Application) PrettyPrint(p *common.SourcePrinter) {
	common.PrettyPrintPrintables(p, a.Elems, " ")
}

func (a ArrowType) PrettyPrint(p *common.SourcePrinter) {
	a.Left.PrettyPrint(p)
	p.WriteString(" -> ")
	a.Right.PrettyPrint(p)
}

func (c Constant) PrettyPrint(p *common.SourcePrinter) {
	p.WriteString(c.Value)
}

func (e Environment) PrettyPrint(p *common.SourcePrinter) {
	if e.IsEmpty() {
		return // empty environment, this is valid
	}

	var lEnclose, rEnclose string
	if len(e.Traits) > 1 {
		lEnclose, rEnclose = "(", ")"
	}

	// write trait tuple (T a, U a b, .., V x)
	p.WriteString(lEnclose)
	common.PrettyPrintPrintables(p, e.Traits, ", ")
	p.WriteString(rEnclose)
	p.WriteString(" => ")
}

func (dec Declaration) PrettyPrint(p *common.SourcePrinter) {
	dec.Ident.PrettyPrint(p)
	p.WriteString(": ")
	dec.Environment.PrettyPrint(p)
	dec.TypeNode.PrettyPrint(p)
}

func (def FunctionDefinition) PrettyPrint(p *common.SourcePrinter) {
	for _, pat := range def.Pattern {
		pat.PrettyPrint(p)
		p.WriteByte(' ')
	}
	p.WriteString("= ")
	def.Assignment.PrettyPrint(p)
}

func (id Ident) PrettyPrint(p *common.SourcePrinter) {
	p.WriteString(id.Value)
}

func (im Import) PrettyPrint(p *common.SourcePrinter) {
	if im.IsEmpty() {
		return // write nothing, nothing was imported
	}
	p.WriteString("import")
	imports := im.All()
	p.IncreaseIndent()
	for _, name := range imports {
		p.Line()
		p.WriteString(name.Key.Value)
		if name.Key.Value != name.Value.Value {
			p.WriteString(" = " + name.Value.Value)
		}
	}
	p.DecreaseIndent()
	p.Line()
	p.WriteString("in ")
}

func (kind KindIdent) PrettyPrint(p *common.SourcePrinter) {
	p.WriteString(kind.Value)
}

func (lambda Lambda) PrettyPrint(p *common.SourcePrinter) {
	p.WriteByte('\\')
	common.PrettyPrintPrintables(p, lambda.Binders, " ")
	p.WriteString(" -> ")
	lambda.Bound.PrettyPrint(p)
}

func (let LetBinding) PrettyPrint(p *common.SourcePrinter) {
	if len(let.Bindings) == 0 {
		return
	}

	p.WriteString("let ")
	block := len(let.Bindings) > 1
	if block {
		p.IncreaseIndent()
		p.Line()
	}
	for i, binding := range let.Bindings {
		binding.PrettyPrint(p)
		if i < len(let.Bindings)-1 {
			p.Line()
		}
	}
	if block {
		p.DecreaseIndent()
	}
	p.WriteString(" in ")
	let.Bound.PrettyPrint(p)
}

func (ls List) PrettyPrint(p *common.SourcePrinter) {
	p.WriteByte('[')
	common.PrettyPrintPrintables(p, ls.Elems, ", ")
	p.WriteByte(']')
}

func (lt ListType) PrettyPrint(p *common.SourcePrinter) {
	p.WriteByte('[')
	lt.Elem.PrettyPrint(p)
	p.WriteByte(']')
}

func (module Module) PrettyPrint(p *common.SourcePrinter) {
	module.Import.PrettyPrint(p)
	module.Use.PrettyPrint(p)
	p.WriteString("module ")
	p.WriteString(module.ModuleName.Value)
	p.WriteString(" where")

	p.IncreaseIndent()
	p.Line()

	if module.Definitions != nil {
		all := module.Definitions.All()
		for _, defs := range all {
			if len(defs.Value) < 1 {
				continue
			}

			for _, def := range defs.Value {
				def.PrettyPrint(p)
				p.Line()
			}
			p.Line()
		}
	}

	p.DecreaseIndent()
	p.WriteString("end")
}

func (def DefinedModuleFunction) PrettyPrint(p *common.SourcePrinter) {
	def.Declaration.PrettyPrint(p)
	p.Line()
	def.FunctionDefinition.PrettyPrint(p)
}

func (paren ParenExpr) PrettyPrint(p *common.SourcePrinter) {
	p.WriteByte('(')
	paren.ExprNode.PrettyPrint(p)
	p.WriteByte(')')
}

func (paren ParenType) PrettyPrint(p *common.SourcePrinter) {
	p.WriteByte('(')
	paren.TypeNode.PrettyPrint(p)
	p.WriteByte(')')
}

func (t TraitDefinition) PrettyPrint(p *common.SourcePrinter) {
	p.WriteString("trait ")
	t.Environment.PrettyPrint(p)

	t.Name.PrettyPrint(p)

	p.WriteString(" where")
	p.IncreaseIndent()
	p.Line()

	// decls
	for _, dec := range t.Declarations {
		dec.PrettyPrint(p)
		p.Line()
	}

	p.DecreaseIndent()
	p.WriteString("end")
}

func (trait Trait) PrettyPrint(p *common.SourcePrinter) {
	trait.Name.PrettyPrint(p)
	if len(trait.Params) == 0 {
		return
	}
	p.WriteByte(' ')
	common.PrettyPrintPrintables(p, trait.Params, " ")
}

func (t TupleKind) PrettyPrint(p *common.SourcePrinter) {
	p.WriteByte('(')
	common.PrettyPrintPrintables(p, t.Elems, ", ")
	p.WriteByte(')')
}

func (t TupleType) PrettyPrint(p *common.SourcePrinter) {
	p.WriteByte('(')
	common.PrettyPrintPrintables(p, t.Elems, ", ")
	p.WriteByte(')')
}

func (a TypeApplication) PrettyPrint(p *common.SourcePrinter) {
	common.PrettyPrintPrintables(p, a.Elems, " ")
}

func (c TypeConstant) PrettyPrint(p *common.SourcePrinter) {
	p.WriteString(c.Value)
}

func (def TypeDefinition) PrettyPrint(p *common.SourcePrinter) {
	Trait(def.Type).PrettyPrint(p)
	p.WriteString(" = ")
	p.IncreaseIndent()
	p.Line()

	if len(def.Constructors) < 1 {
		panic("bug: tried to print illegal type type definition")
	}

	def.Constructors[0].PrettyPrint(p)
	for i := 1; i < len(def.Constructors); i++ {
		p.Line()
		p.WriteString("| ")
		def.Constructors[i].PrettyPrint(p)
	}
	p.DecreaseIndent()
}

func (t TypeJudgment) PrettyPrint(p *common.SourcePrinter) {
	t.ExprNode.PrettyPrint(p)
	p.WriteString(": ")
	t.TypeNode.PrettyPrint(p)
}

func (v TypeVariable) PrettyPrint(p *common.SourcePrinter) {
	p.WriteString(v.Value)
}

func (use Use) PrettyPrint(p *common.SourcePrinter) {
	if use.IsEmpty() {
		return // no use-imports
	}

	p.WriteString("use")
	uses := use.All()
	p.IncreaseIndent()
	for _, name := range uses {
		p.Line()
		p.WriteString(name.Key.Value)
	}
	p.DecreaseIndent()
	p.Line()
	p.WriteString("in ")
}

func (a AliasDefinition) Pos() (start, end int) {
	return a.Start, a.End
}

func (a Application) Pos() (start, end int) {
	return a.Start, a.End
}

func (a ArrowType) Pos() (start, end int) {
	return a.Start, a.End
}

func (c Constant) Pos() (start, end int) {
	return c.Start, c.End
}

func (env Environment) Pos() (start, end int) {
	return env.Start, env.End
}

func (dec Declaration) Pos() (start, end int) {
	_, end = dec.TypeNode.Pos()
	return dec.Ident.Start, end
}

func (def FunctionDefinition) Pos() (start, end int) {
	return def.Start, def.End
}

func (id Ident) Pos() (start, end int) {
	return id.Start, id.End
}

func (im Import) Pos() (start, end int) {
	return im.Start, im.End
}

func (kind KindIdent) Pos() (start, end int) {
	return kind.Start, kind.End
}

func (lambda Lambda) Pos() (start, end int) {
	return lambda.Start, lambda.End
}

func (let LetBinding) Pos() (start, end int) {
	return let.Start, let.End
}

func (ls List) Pos() (start, end int) {
	return ls.Start, ls.End
}

func (lt ListType) Pos() (start, end int) {
	return lt.Start, lt.End
}

func (module Module) Pos() (start, end int) {
	return module.Start, module.End
}

func (def DefinedModuleFunction) Pos() (start, end int) {
	return def.FunctionDefinition.Pos()
}

func (paren ParenExpr) Pos() (start, end int) {
	return paren.Start, paren.End
}

func (paren ParenType) Pos() (start, end int) {
	return paren.Start, paren.End
}

func (trait Trait) Pos() (start, end int) {
	return trait.Start, trait.End
}

func (def TraitDefinition) Pos() (start, end int) {
	return def.Start, def.End
}

func (t TupleKind) Pos() (start, end int) {
	return t.Start, t.End
}

func (t TupleType) Pos() (start, end int) {
	return t.Start, t.End
}

func (a TypeApplication) Pos() (start, end int) {
	return a.Start, a.End
}

func (c TypeConstant) Pos() (start, end int) {
	return c.Start, c.End
}

func (def TypeDefinition) Pos() (start, end int) {
	return def.Start, def.End
}

func (t TypeJudgment) Pos() (start, end int) {
	start, _ = t.ExprNode.Pos()
	_, end = t.TypeNode.Pos()
	return
}

func (v TypeVariable) Pos() (start, end int) {
	return v.Start, v.End
}

func (use Use) Pos() (start, end int) {
	return use.Start, use.End
}

func (a ArrowType) ToType() types.Monotype {
	return types.Application{
		TypeConst: types.FunctionTypeConst,
		Args:      []types.Monotype{a.Left.ToType(), a.Right.ToType()},
	}
}

func (ls ListType) ToType() types.Monotype {
	return types.Application{
		TypeConst: types.ListTypeConst,
		Args:      []types.Monotype{ls.Elem.ToType()},
	}
}

func (p ParenType) ToType() types.Monotype {
	return p.TypeNode.ToType()
}

func (t TupleType) ToType() types.Monotype {
	ms := make([]types.Monotype, len(t.Elems))
	for i, elem := range t.Elems {
		ms[i] = elem.ToType()
	}
	return types.Tuple(ms)
}

// panics if len(a.Elems) < 2
func (a TypeApplication) ToType() types.Monotype {
	if len(a.Elems) < 2 {
		panic("illegal argument")
	}

	ms := make([]types.Monotype, len(a.Elems))
	for i, elem := range a.Elems {
		ms[i] = elem.ToType()
	}

	return types.Application{
		TypeConst: ms[0].(types.ReferenceType),
		Args:      ms[1:],
	}
}

func (c TypeConstant) ToType() types.Monotype {
	return types.Constant(c.String())
}

func (v TypeVariable) ToType() types.Monotype {
	return types.Variable(v.String())
}

func (a Application) Substitute(m *common.Table[Ident, ExprNode]) ExprNode {
	out := Application{Start: a.Start, End: a.End, Elems: make([]ExprNode, len(a.Elems))}
	for i, e := range a.Elems {
		out.Elems[i] = e.Substitute(m)
	}
	return out
}

func (c Constant) Substitute(*common.Table[Ident, ExprNode]) ExprNode {
	return c
}

func (ident Ident) Substitute(m *common.Table[Ident, ExprNode]) ExprNode {
	if e, found := m.Find(ident); found {
		return e
	}
	return ident
}

func (kind KindIdent) Substitute(*common.Table[Ident, ExprNode]) ExprNode {
	return kind
}

func (Lambda) Substitute(*common.Table[Ident, ExprNode]) ExprNode {
	panic("illegal function call")
}

func (LetBinding) Substitute(*common.Table[Ident, ExprNode]) ExprNode {
	panic("illegal function call")
}

func (list List) Substitute(m *common.Table[Ident, ExprNode]) ExprNode {
	out := List{Start: list.Start, End: list.End, Elems: make([]ExprNode, len(list.Elems))}
	for i, e := range list.Elems {
		out.Elems[i] = e.Substitute(m)
	}
	return out
}

func (pe ParenExpr) Substitute(m *common.Table[Ident, ExprNode]) ExprNode {
	return ParenExpr{
		Start:    pe.Start,
		End:      pe.End,
		ExprNode: pe.ExprNode.Substitute(m),
	}
}

func (t TupleKind) Substitute(m *common.Table[Ident, ExprNode]) ExprNode {
	out := TupleKind{Start: t.Start, End: t.End, Elems: make([]ExprNode, len(t.Elems))}
	for i, e := range t.Elems {
		out.Elems[i] = e.Substitute(m)
	}
	return out
}

// defines type alias
func (a AliasDefinition) Visit(parser *Parser) (en ExprNode, ok bool) {
	// convert to idents
	idents := make([]module.Ident, len(a.Aliased.Params))
	for i, tv := range a.Aliased.Params {
		idents[i] = module.Ident(tv)
	}

	aliasName := module.TypeConstant(a.Alias)
	aliased := module.TypeConstant(a.Aliased.Name)
	// create alias
	alias := module.MakeAlias(aliasName, idents, aliased)

	// define type alias
	var redef bool
	ok, redef = parser.Symbols.Alias(alias)

	// handle redefinition and undefined errors
	if redef { // redef==true => ok==false
		parser.nameError2(RedefAlias, aliasName.Start, aliasName.End)
		return
	} else if !ok {
		parser.nameError2(UndefinedType, aliasName.Start, aliasName.End)
		return
	}

	return
}

func (a Application) Visit(parser *Parser) (en ExprNode, ok bool) {
	// visit children
	for i, elem := range a.Elems {
		en, ok = elem.Visit(parser)
		if !ok {
			return
		}
		a.Elems[i] = en
	}

	// do re-ordering pass of parser
	for _, elem := range a.Elems {
		ok = elem.Action(parser)
		if !ok {
			return
		}
	}

	for parser.exprStack.GetCount() > 1 && ok {
		ok = parser.apply()
	}

	if !ok {
		return
	}

	if parser.exprStack.GetCount() == 0 {
		panic("bug: empty expression stack")
	}

	en, _ = parser.exprStack.Pop()
	if _, ok = en.(Application); !ok {
		panic("bug: illegal ExprNode on expression stack, expected Application")
	}

	return
}

func (a ArrowType) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (c Constant) Visit(parser *Parser) (en ExprNode, ok bool) {
	return c, true
}

func (env Environment) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (dec Declaration) Visit(parser *Parser) (en ExprNode, ok bool) {
	// handle sym creation annotations
	binding, prec, arity := parser.annotateSymbolDeclaration(dec.Annotations)
	module.MakeSymbol()
	ok = true
	return
}

func (def FunctionDefinition) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

// this visits an identifier use, not declaration
func (id Ident) Visit(parser *Parser) (en ExprNode, ok bool) {
	return id, true
}

func (im Import) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

// this visits a kind identifier use, not declaration
func (kind KindIdent) Visit(parser *Parser) (en ExprNode, ok bool) {
	return kind, true
}

func (lambda Lambda) Visit(parser *Parser) (en ExprNode, ok bool) {
	parser.Symbols.AddScope()
	for _, binder := range lambda.Binders {
		sym := module.MakeSymbol(module.Ident(binder), 0, 0, 0)
		parser.Symbols.DefineSymbol(sym)
	}

	lambda.Bound, ok = lambda.Bound.Visit(parser)
	if !ok {
		return
	}

	parser.Symbols.RemoveScope()
	return lambda, ok
}

func (let LetBinding) Visit(parser *Parser) (en ExprNode, ok bool) {
	parser.Symbols.AddScope()
	for _, binding := range let.Bindings {
		// TODO: need to account for being assigned to a lambda function.
		// This will change the binder's symbol since the arity will be >= 1
		sym := module.MakeSymbol(binding)
	}
}

func (ls List) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true // accounts for empty lists
	for i, elem := range ls.Elems {
		ls.Elems[i], ok = elem.Visit(parser)
		if !ok {
			return
		}
	}

	return ls, ok
}

func (lt ListType) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (module Module) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true // no defs is ok
	for _, defs := range module.Definitions.All() {
		for _, def := range defs.Value {
			_, ok = def.Visit(parser)
			if !ok {
				return
			}
		}
	}
	return
}

func (def DefinedModuleFunction) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (paren ParenExpr) Visit(parser *Parser) (en ExprNode, ok bool) {
	paren.ExprNode, ok = paren.ExprNode.Visit(parser)
	return paren, ok
}

func (paren ParenType) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (trait Trait) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (def TraitDefinition) Visit(parser *Parser) (en ExprNode, ok bool) {
	// TODO: environment
	syms := make([]module.Symbol, len(def.Declarations))
	for i, dec := range def.Declarations {
		syms[i] = module.MakeSymbol(module.Ident(dec.Ident), dec)
	}
	traitDefSym := module.MakeTrait(module.TypeConstant(def.Name.Name), def.Declarations)
	//traitDefSym :=
	ok = true
	return
}

func (t TupleKind) Visit(parser *Parser) (en ExprNode, ok bool) {
	for i, elem := range t.Elems {
		t.Elems[i], ok = elem.Visit(parser)
		if !ok {
			return
		}
	}

	if !ok { // empty tuple, something went wrong
		panic("bug: empty tuple caught during visit, should've been caught sooner")
	}

	return t, ok
}

func (t TupleType) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (a TypeApplication) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (c TypeConstant) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

// defines types and their constructors
func (def TypeDefinition) Visit(parser *Parser) (en ExprNode, ok bool) {
	typ := def.Type
	typeSymbol := SymbolizeType(typ)
	ok = parser.Symbols.DefineType(typeSymbol)
	if !ok {
		parser.error2(RedefType, typ.Start, typ.End)
		return
	}

	cons := def.SymbolizeConstructors(typeSymbol)
	for _, con := range cons {
		ok = parser.Symbols.DefineTypeConstructor(con)
		if !ok {
			parser.error2(RedefTypeCons, typ.Start, typ.End)
			return
		}
	}
	return
}

func (t TypeJudgment) Visit(parser *Parser) (en ExprNode, ok bool) {
	// TODO: ?
	ok = true
	return
}

func (v TypeVariable) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

func (use Use) Visit(parser *Parser) (en ExprNode, ok bool) {
	ok = true
	return
}

// definitions
func (AliasDefinition) definitionNode()       {}
func (FunctionDefinition) definitionNode()    {}
func (DefinedModuleFunction) definitionNode() {}
func (TraitDefinition) definitionNode()       {}
func (TypeDefinition) definitionNode()        {}

// expressions
func (Application) exprNode() {}
func (Constant) exprNode()    {}
func (Ident) exprNode()       {}
func (KindIdent) exprNode()   {}
func (Lambda) exprNode()      {}
func (LetBinding) exprNode()  {}
func (List) exprNode()        {}
func (ParenExpr) exprNode()   {}
func (TupleKind) exprNode()   {}

// patterns
func (Application) patternNode() {}
func (Constant) patternNode()    {}
func (Ident) patternNode()       {}
func (KindIdent) patternNode()   {}
func (List) patternNode()        {}
func (ParenExpr) patternNode()   {}
func (TupleKind) patternNode()   {}

// types
func (ArrowType) typeNode()             {}
func (DependentFunctionType) typeNode() {}
func (ListType) typeNode()              {}
func (ParenType) typeNode()             {}
func (TupleType) typeNode()             {}
func (TypeApplication) typeNode()       {}
func (TypeConstant) typeNode()          {}
func (TypeVariable) typeNode()          {}
func (VarJudgment) typeNode()           {}

// function types
func (ArrowType) StrictlyDepType() bool             { return false }
func (DependentFunctionType) StrictlyDepType() bool { return true }

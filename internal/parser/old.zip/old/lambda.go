// =================================================================================================
// Alex Peters - January 25, 2024
// =================================================================================================
package parser

import "github.com/petersalex27/yew/token"

// parse lambda binders
func (parser expressionParser) parseBinders(lambda *Lambda) bool {
	v, ok := parser.parseVariableId() // first variable binder is required
	if !ok {
		return false
	}
	lambda.Binders = []Ident{v}
	again := parser.Peek().Type == token.Id
	for again {
		v, ok = parser.parseVariableId()
		if !ok {
			return false 
		}

		lambda.Binders = append(lambda.Binders, v)
		again = parser.Peek().Type == token.Id
	}
	return true
}

func (parser expressionParser) parseLambda() (lambda Lambda, ok bool) {
	var backslash token.Token
	if backslash, ok = parser.backslashToken(); !ok {
		return
	}
	lambda.Start = backslash.Start

	if ok = parser.parseBinders(&lambda); !ok {
		return
	}

	if _, ok = parser.bindingArrowToken(); !ok {
		return
	}

	if lambda.Bound, ok = parser.parseExpression(); !ok {
		return
	}

	_, lambda.End = lambda.Bound.Pos()
	return
}

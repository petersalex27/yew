# Definition and Declaration Dependency Tree

```
Func. Decl.             Monotype Decl.
│            ┌──────────┤
Dep. Type Decl.         Monotype Def.
             │          │
            Func. Judgment
             │          │
        Func. Def.      Dep. Type Def.
```
// =================================================================================================
// Alex Peters - January 24, 2024
//
// The actual parsing functions/methods
// =================================================================================================

package parser

import (
	"strings"

	"github.com/petersalex27/yew/token"
)

// AssignDeclaration finds the associated declaration for `function`, then it returns a function
// which is ready to be defined within the current module.
//
// If an associated declaration is not found, a very general declaration is created from `function`
// instead. This, as if it were to have been found, will be used to create a function ready to be
// defined within the current module.
func (parser *Parser) AssignDeclaration(function FunctionDefinition) (def DefinedModuleFunction, ok bool) {
	// true iff declaration is **found**
	var found bool
	def = DefinedModuleFunction{FunctionDefinition: function}
	pattern := function.Pattern
	def.Declaration, found = parser.forwardPatternMatch(pattern)
	if ok = found; !ok {
		def.Declaration, ok = parser.GenerateDeclaration(function)
	}
	return
}

// finishes defining any functions not yet defined and returns true if all current module's
// functions are defined w/o errors (NOTE: this means if module == nil, this function returns true).
//
// this should be called after imported symbols have been resolved so that trait membership can
// be defined too
func (parser *Parser) DefineModuleFunctions() (ok bool) {
	if parser.module == nil {
		// vacuously true that all of module's functions were defined
		return true
	}

	ok = true
	for _, function := range parser.Functions {
		var def DefinedModuleFunction
		if def, ok = parser.AssignDeclaration(function); !ok {
			return
		}
		name := def.Declaration.Ident.Token
		parser.module.Define(name, def)
	}
	return
}

// generates a very general declaration for `function`, returning the result
func (parser *Parser) GenerateDeclaration(function FunctionDefinition) (*Declaration, bool) {
	// given a function definition:
	//	f x y z = <expression>
	// one can deduce the type can be generalized to:
	//	typeof(x) -> typeof(y) -> typeof(z) -> Type
	// the number of parts to this function is length of params + 1 (+1 for return type)--but, the
	// params, assuming `function` is a valid definition, are just everything but the first elem
	// of `function.Pattern`. Thus, the len of `function.Pattern` gives length of params plus one.
	numParts := len(function.Pattern)
	if numParts < 1 {
		panic("bug: illegal function, no name and no params (pattern is empty)")
	}

	ty := ArrowType{Types: make([]TypeNode, numParts)}
	for i := 0; i < numParts; i++ {
		ty.Types[i] = parser.GenerateUniqueTypeVar()
	}
	
	ident, success := AttemptIdentification(function.Pattern)
	if !success {
		startPos, _ := function.Pattern[0].Pos()
		_, endPos := function.Pattern[len(function.Pattern)-1].Pos()
		parser.error2(IllegalPattern, startPos, endPos)
		return nil, false
	}

	if strings.Contains(ident.Value, "_") {
		parser.error(IllegalImplicitDeclaration)
		return nil, false
	}

	return parser.Declare([]Annotation{}, ident, ty)
}

func (parser *Parser) GenerateUniqueTypeVar() TypeVariable {
	v := token.Id.MakeValued(parser.UniqueId())
	return TypeVariable{v}
}

// looks at the next token and decides whether it can be dropped:
//   - if it's a newline, returns the truthy of the parser's allowNewlineDropping flag
//   - if it's a comment, returns the truthy of the parser's drop comment flag
//   - otherwise, returns false
func (parser expressionParser) droppable() bool {
	switch parser.Peek().Type {
	case token.Newline:
		return parser.allowNewlineDropping
	case token.Comment:
		return parser.dropComments
	default:
		return false
	}
}

// looks at the next token and decides whether it can be dropped:
//   - if it's a newline, returns true
//   - if it's a comment, returns the truthy of the parser's drop comment flag
//   - otherwise, returns false
func (parser *Parser) droppable() bool {
	switch parser.Peek().Type {
	case token.Newline:
		return true
	case token.Comment:
		return parser.dropComments
	default:
		return false
	}
}

// drops any "droppable" things--what's droppable depends on receiver and its flags
func (parser expressionParser) dropDroppables() {
	for parser.droppable() {
		_ = parser.Advance()
	}
}

// drops any "droppable" things--what's droppable depends on receiver and its flags
func (parser *Parser) dropDroppables() {
	for parser.droppable() {
		_ = parser.Advance()
	}
}

// =================================================================================================
// Alex Peters - January 27, 2024
//
// builtin annotations
// =================================================================================================
package parser

import (
	"github.com/petersalex27/yew/module"
	"github.com/petersalex27/yew/token"
)

var filePrivateAnnotationToken = token.At.MakeValued("fprivate")

// returns an annotation declaring that 'privatizing' has file-private visibility
//
// annotation looks like so:
//
//	@fprivate
func FPrivateAnnotation(privatizing token.Token) Annotation {
	return Annotation{
		Start: privatizing.Start,
		End:   privatizing.End,
		Name:  filePrivateAnnotationToken,
	}
}

// returns an annotation declaring the precedence and associativity of a symbol
//
// example annotation
//
//	@affix Left 3
func AffixAnnotation(annotation token.Token, associativity KindIdent, precedence Constant) Annotation {
	return Annotation{
		Start: annotation.Start,
		End:   precedence.End,
		Name:  annotation,
		Args:  []Node{associativity, precedence},
	}
}

// returns an annotation declaring the location of an instruction `instr`
//
// example annotation
//
//	@instr "iadd i64 _ _"
func InstrAnnotation(annotation token.Token, instr Constant) Annotation {
	return Annotation{
		Start: annotation.Start,
		End:   instr.End,
		Name:  annotation,
		Args:  []Node{instr},
	}
}

func TypeasAnnotation(annotation token.Token, typeas Constant) Annotation {
	return Annotation{
		Start: annotation.Start,
		End:   typeas.End,
		Name:  annotation,
		Args:  []Node{typeas},
	}
}

// clears annotations from stack and returns them so they can be applied to some node
func (parser *Parser) annotate() (annots []Annotation) {
	size := parser.annotationStack.GetCount()
	if size == 0 {
		// MultiCheck(0) would return nil, so return this instead
		return []Annotation{}
	}

	annots, _ = parser.annotationStack.MultiCheck(int(size))
	parser.annotationStack.Clear(size) // clear stack
	return
}

func (parser *Parser) AnnotateDeclaration(dec Declaration) Declaration {
	dec.Annotations = parser.annotate()
	return dec
}

func (parser *Parser) annotateSymbolDeclaration(annotations []Annotation) (binding module.Binding, prec uint8, arity uint) {
	panic("TODO: implement")
}

func (parser *Parser) parseAnnotationBody(annot *Annotation) (ty token.Type, ok bool) {
	switch ty = parser.Peek().Type; ty {
	case token.IntValue:
		fallthrough
	case token.CharValue:
		fallthrough
	case token.StringValue:
		fallthrough
	case token.FloatValue:
		val := parser.Advance()
		annot.Args, ok = append(annot.Args, Constant{val}), true
	case token.CapId:
		kind := parser.Advance()
		annot.Args, ok = append(annot.Args, KindIdent{kind}), true
	default:
		ok = false
	}
	return
}

func (parser *Parser) parseAnnotation() (ok bool) {
	var annotToken token.Token
	if annotToken, ok = parser.annotationToken(); !ok {
		return
	}

	var annot Annotation
	annot.Name = annotToken
	annot.Start = annotToken.Start
	annot.Args = []Node{}

	ty := parser.Peek().Type
	for ty != token.Newline && ty != token.EndOfTokens {
		_, ok = parser.parseAnnotationBody(&annot)
		if !ok {
			return
		}
		ty = parser.Peek().Type
	}

	if len(annot.Args) > 0 {
		_, annot.End = annot.Args[len(annot.Args)-1].Pos()
	} else {
		annot.End = annotToken.End
	}

	parser.annotationStack.Push(annot)
	return
}

func (parser *Parser) parseEnclosedAnnotation() (ok bool) {
	var lparen token.Token
	if lparen, ok = parser.leftParen(); !ok {
		return
	}

	var annotToken token.Token
	if annotToken, ok = parser.annotationToken(); !ok {
		return
	}

	var annot Annotation
	annot.Name = annotToken
	annot.Start = lparen.Start
	annot.Args = []Node{}

	ty := parser.Peek().Type
	for ty != token.RightParen {
		_, ok = parser.parseAnnotationBody(&annot)
		if !ok {
			return
		}
		ty = parser.Peek().Type
	}

	var rparen token.Token
	if rparen, ok = parser.rightParenToken(); !ok {
		return
	}

	annot.End = rparen.End
	parser.annotationStack.Push(annot)
	return
}

// =================================================================================================
// Alex Peters - January 31, 2024
//
// various utility methods and functions
// =================================================================================================
package parser

import (
	"fmt"
	"math"
	"regexp"

	"github.com/petersalex27/yew/common"
	"github.com/petersalex27/yew/token"
)

var alphaNumericId = regexp.MustCompile(`[a-z][a-zA-Z0-9']*`)

// returns true iff **entire** string matches the following regex:
//
//	`[a-z][a-zA-Z0-9']*`
func isAlphaNumeric[S fmt.Stringer](s S) bool {
	str := s.String()
	// matched string has same length as original string implies string was completely matched
	return len(alphaNumericId.FindString(str)) == len(str)
}

// returns true iff token has the type `token.Id` and **entire** token value string matches the
// following regex:
//
//	`[a-z][a-zA-Z0-9']*`
func isAlphaNumericId(tok token.Token) bool {
	return tok.Type == token.Id && isAlphaNumeric(tok)
}

// maps id to lookup in import map
//
// if id already added to map, then an error is reported and this function returns false
func (parser *Parser) mapUniqueId(table *common.Table[token.Token, token.Token], id, lookup token.Token) (ok bool) {
	if _, found := table.Find(id); found {
		ok = false
		parser.error(IllegalReimport)
		return
	}

	table.Map(id, lookup)
	return true
}

// splits a string with underscores into a slice of each of the parts separated by underscores and
// the underscores. Examples:
//
//	splitIdent("if_then_else_") == []string{"if", "_", "then", "_", "else", "_"}
//	splitIdent("_+_") == []string{"_", "+", "_"}
func splitIdent(ident string) []string {
	res := []string{}
	s := []byte("")
	for _, r := range ident {
		if r != '_' {
			s = append(s, byte(r))
			continue
		}

		if len(s) != 0 {
			res = append(res, string(s))
			s = []byte("")
		}
		res = append(res, "_")
	}

	if len(s) != 0 {
		res = append(res, string(s))
	}
	return res
}

// takes nodes and finds the start and end position of them regardless of the order
func startEnd(ns ...Node) (start, end int) {
	min := math.MaxInt // sentinel value
	max := math.MinInt // sentinel value
	for _, n := range ns {
		minTmp, maxTmp := n.Pos()
		min, max = common.Min(min, minTmp), common.Max(max, maxTmp)
	}
	if min > max {
		panic("no args or illegal positions")
	}
	return min, max
}

// =================================================================================================
// Alex Peters - January 27, 2024
//
// Pattern matching
// =================================================================================================

package parser

// returns true iff `pattern[:]` syntactically matches `declaration.Split[:]`
//
// the following determines if something is a syntactic match:
//   - both `pattern` and `Split` must have the same length
//   - each element i of `pattern` must match element i of `Split`
//   - an element p of `pattern` matches an element s of `Split` when one of two conditions are true:
//   - (1) p is an Ident AND p.(Ident).Value identical to s
//   - (2) s is "_"
func SyntacticMatch(pattern []PatternNode, declaration Declaration) bool {
	if len(pattern) != len(declaration.Split) {
		return false
	}

	for i, s := range declaration.Split {
		if s == "_" {
			continue
		}
		p := pattern[i]
		if ident, ok := p.(Ident); !ok || ident.Value != s {
			return false
		}
	}
	return true
}

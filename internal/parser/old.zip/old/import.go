// =================================================================================================
// Alex Peters - January 25, 2024
//
// Handles parsing of imports
// =================================================================================================
package parser

import (
	"github.com/petersalex27/yew/common"
	"github.com/petersalex27/yew/token"
)

// returns true iff there's nothing to import
func (im Import) IsEmpty() bool {
	return im.Table == nil
}

// attempts to merge two imports. Fails, returning false, if there is a conflict when merging.
//
// example:
//
//	import -- dest
//		this
//		that
//	in import -- src
//		this -- conflict!!
//	in ...
//	dest and src try to import the same thing, then IllegalReimport is reported and
//
// false is returned
func (parser *Parser) mergeImports(dest *Import, src Import) (ok bool) {
	for _, importPair := range src.All() {
		id, lookup := importPair.Key, importPair.Value
		if ok = parser.mapUniqueId(dest.Table, id, lookup); !ok {
			return
		}
	}
	return
}

// parses 'import' through 'in'
func (parser *Parser) parseImport() (im Import, ok bool) {
	var importKeyword token.Token
	if importKeyword, ok = parser.importToken(); !ok {
		return
	}
	im.Start = importKeyword.Start
	// choice of 8 is mostly arbitrary, it's just an small power of two
	const initialCap int = 8
	im.Table = common.MakeTable[token.Token, token.Token](initialCap)

	parser.dropDroppables()
	ok = parser.Peek().Type == token.Id
	if !ok {
		parser.error(IllegalImport)
		return
	}

	for again := true; again && ok; {
		again, ok = parser.parseImportIteration(&im)
	}

	if !ok {
		return
	}

	var in token.Token
	if in, ok = parser.inToken(); ok {
		im.End = in.End
	}
	return
}

func (parser *Parser) parseImportIteration(im *Import) (again, ok bool) {
	var id, lookup token.Token
	id, ok = parser.variableIdToken()

	// get lookup name
	if ok && parser.Peek().Type == token.Equal {
		_ = parser.Advance() // advance past '='
		lookup, ok = parser.variableIdToken()
	} else if ok {
		lookup = id // same as id
	}

	// catches "!ok"s from failure of getting id and lookup
	if !ok {
		return
	}

	parser.mapUniqueId(im.Table, id, lookup)
	parser.dropDroppables()
	again = parser.Peek().Type == token.Id
	return
}

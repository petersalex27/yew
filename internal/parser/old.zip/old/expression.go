// =================================================================================================
// Alex Peters - January 26, 2024
// =================================================================================================

package parser

import "github.com/petersalex27/yew/token"

// one iteration of parenthesized expression parse
func (parser expressionParser) iterateParenParse() (right ExprNode, end bool) {
	var ok bool
	right, ok = parser.parseExpression()
	if end = !ok; end {
		return
	}
	parser.dropDroppables()
	end = parser.Peek().Type == token.RightParen || parser.Peek().Type == token.EndOfTokens
	return
}

// parses one element and a separator in a list-like expression
//
//   - param listLike: pointer to list-like AST node, its field `Elems` will be filled in with
//     expression nodes
//   - param separatorType: type that separates expression elements
//   - param endType: type that denotes end of list-like
//
// returns true iff parsing should end. Note that this includes returning true when there is an
// error, not only when `endType` is found. To check if an error occurred, call
// `(*Parser) Panicking()`
//
// SEE:
//
//	(*Parser) Panicking()
func (parser expressionParser) iterateListLikeParse(listLike *ListLike, separatorType token.Type, endType token.Type) (end bool) {
	next, ok := parser.parseExpression()
	if end = !ok; end {
		return
	}

	listLike.Elems = append(listLike.Elems, next)
	parser.dropDroppables()
	var forceEnd bool
	if forceEnd = parser.Peek().Type != separatorType; !forceEnd {
		_ = parser.Advance()
		parser.dropDroppables()
	}

	// if forceEnd and not next is not a right paren, error will be thrown later when right paren is
	// checked for but not found
	end = forceEnd || parser.Peek().Type == endType || parser.Peek().Type == token.EndOfTokens
	return
}

// handles iterative logic for parsing parenthesized expressions
func (parser expressionParser) loopParenParse(e ExprNode) (_ ExprNode, ok bool) {
	end := parser.Peek().Type == token.RightParen || parser.Peek().Type == token.EndOfTokens
	if end {
		return e, true
	}

	a := Application{}
	a.Elems = []ExprNode{e}
	for !end {
		e, end = parser.iterateParenParse()
		if !end {
			a.Elems = append(a.Elems, e)
		}
	}
	a.Start, _ = a.Elems[0].Pos()
	_, a.End = a.Elems[len(a.Elems)-1].Pos()
	return a, !parser.panicking
}

func (parser expressionParser) parseApplication(first ExprNode) (a Application, ok bool) {
	again := true
	a.Elems = []ExprNode{first}
	for e := ExprNode(nil); again; {
		e, again = parser.parseExpressionIteration()
		if again {
			a.Elems = append(a.Elems, e)
		}
	}
	a.Start, _ = a.Elems[0].Pos()
	_, a.End = a.Elems[len(a.Elems)-1].Pos()
	return a, !parser.panicking
}

func (parser expressionParser) parseElements(initElems []ExprNode, separatorType, endType token.Type) (listLike ListLike, ok bool) {
	listLike.Elems = initElems
	end := parser.Peek().Type == endType || parser.Peek().Type == token.EndOfTokens
	for !end {
		end = parser.iterateListLikeParse(&listLike, separatorType, endType)
	}
	ok = parser.validateEndOfListLike(endType)
	return
}

// parses an expression enclosed by parentheses
func (parser expressionParser) parseEnclosed(start int) (pe PatternNode, ok bool) {
	parser.dropDroppables()

	var e ExprNode
	e, ok = parser.parseExpression()
	if !ok {
		return
	}

	parser.dropDroppables()

	// is it `(e, ...` ?
	isTuple := parser.Peek().Type == token.Comma
	if isTuple {
		_ = parser.Advance()
		return parser.parseTuple(e, start)
	}

	if e, ok = parser.loopParenParse(e); !ok {
		return
	} else if ok = parser.Peek().Type == token.RightParen; !ok {
		parser.error(UnexpectedEOF)
		return
	}

	end := parser.Advance().End
	pe = ParenExpr{Start: start, End: end, ExprNode: e}

	return
}

// a single expression parse iteration
//
// parses the following:
//   - integers
//   - characters
//   - floating point values
//   - strings
//   - IDs (including affixed ones)
//   - parenthesized expressions
//   - lists
//   - tuples
//   - other non-builtin data types (recognized by starting w/ upper case name)
func (parser expressionParser) parseExpressionIteration() (expression ExprNode, ok bool) {
	tokenType := parser.Peek().Type
	switch tokenType {
	case token.IntValue:
		fallthrough
	case token.CharValue:
		fallthrough
	case token.FloatValue:
		fallthrough
	case token.StringValue:
		expression, ok = Constant{parser.Advance()}, true
	case token.Id:
		fallthrough
	case token.Affixed:
		expression, ok = Ident{parser.Advance()}, true
	case token.LeftBracket:
		start := parser.Advance().Start
		expression, ok = parser.parseList(start)
	case token.CapId:
		expression, ok = KindIdent{parser.Advance()}, true
	case token.LeftParen:
		start := parser.Advance().Start
		expression, ok = parser.parseEnclosed(start)
	case token.Backslash:
		expression, ok = parser.parseLambda()
	case token.Let:
		expression, ok = parser.parseLetBinding()
	}
	return
}

func (parser expressionParser) parseExpression() (expression ExprNode, ok bool) {
	expression, ok = parser.parseExpressionIteration()

	// `again` is just for readability
	if again := ok; again {
		return parser.parseApplication(expression)
	}

	// set true value of ok (it's possible parseExpressionIteration just read nothing)
	ok = !parser.panicking
	return
}

func (parser expressionParser) parseList(start int) (ls List, ok bool) {
	ls, ok = parser.parseElements([]ExprNode{}, token.Comma, token.RightBracket)
	if ok {
		ls.Start = start
		ls.End = parser.Advance().End
	}
	return
}

func (parser expressionParser) parseTuple(first ExprNode, start int) (tuple TupleKind, ok bool) {
	tuple, ok = parser.parseElements([]ExprNode{first}, token.Comma, token.RightParen)
	if ok {
		tuple.Start = start
		tuple.End = parser.Advance().End
	}
	return
}

func (parser expressionParser) validateEndOfListLike(expect token.Type) (ok bool) {
	if ok = parser.Peek().Type == expect; !ok {
		if parser.Peek().Type == token.EndOfTokens {
			parser.error(UnexpectedEOF)
			return
		}
		errorMessage := getExpectMessage(expect)
		parser.error(errorMessage)
	}
	return
}

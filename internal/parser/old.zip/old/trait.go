// =================================================================================================
// Alex Peters - January 30, 2024
// =================================================================================================
package parser

// parses occurrence of a trait (not a trait definition!!)--these will usually show up in the
// creation of a typing environment or in a trait declaration position of a trait definition
func (parser *Parser) parseTrait() (trait Trait, ok bool) {
	if trait.Name, ok = parser.parseTypeConstant(); !ok {
		return
	}
	trait.Start = trait.Name.Start

	if trait.Params, ok = parser.parseParams(); !ok {
		return
	}
	paramLen := len(trait.Params)
	if ok = paramLen >= 1; !ok {
		parser.error(IllegalTraitNoParams)
		return
	}
	trait.End = trait.Params[paramLen-1].End
	return
}

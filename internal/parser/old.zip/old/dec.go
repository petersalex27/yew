// =================================================================================================
// Alex Peters - February 03, 2024
// =================================================================================================
package parser

func (parser *Parser) DeclareAlias(alias TypeConstant, aliased TypeConstant) (ok bool) {
	key := alias.Token.String()
	_, found := parser.types[key]
	if ok = !found; !ok {
		parser.error2(IllegalTypeRedeclaration, alias.Start, alias.End)
		return
	}

	parser.typeAliases[key] = aliased
	return
}

func (parser *Parser) DeclareTrait(trait TraitDefinition) (ok bool) {
	// TODO: parser.annotateTraitDeclaration(trait)
	key := trait.Name.Name.String()
	_, found := parser.traits[key]
	if ok = !found; !ok {
		parser.error2(IllegalTraitRedeclaration, trait.Start, trait.End)
		return
	}

	parser.traits[key] = trait
	return
}

func (parser *Parser) DeclareType(ty ParameterizedTypeLike) (ok bool) {
	key := ty.Name.String()
	_, found := parser.types[key]
	if ok = !found; !ok {
		parser.error2(IllegalTypeRedeclaration, ty.Start, ty.End)
		return
	}

	parser.types[key] = ty
	return
}

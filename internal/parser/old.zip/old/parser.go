// =================================================================================================
// Alex Peters - January 24, 2024
//
// Parser struct and methods
// =================================================================================================

package parser

import (
	"fmt"

	"github.com/petersalex27/yew/common/stack"
	"github.com/petersalex27/yew/errors"
	"github.com/petersalex27/yew/module"
	"github.com/petersalex27/yew/source"
	"github.com/petersalex27/yew/token"
)

type info struct {
	arity      uint
	precedence uint8
	postfixed  bool
	right      bool
}

// turns a slice of tokens into an AST rooted at a `File` struct
//
// SEE: `parser.File`
type Parser struct {
	// records the number of definitions
	//
	// this is here to ensure that pattern matching definitions are contiguous
	//
	// for example, this should be valid:
	//	last x::[] = x				-- definition #1
	//	last x::xs = last xs	-- definition #2
	//	first xs = head xs		-- definition #3
	// but this should not be
	//	last x::[] = x				-- definition #1
	//	first xs = head xs		-- definition #2
	//	last x::xs = last xs	-- definition #3
	// since when you list out all the definitions numbers of last you get:
	//	1, 3
	// and because 3 - 1 > 1, there's a definition b/w "last" defs
	definitionNumber int
	// used to create unique identifiers
	uniqueIdCounter uint
	// stack of declarations: (num elems in head, patterns of heads w/ num elems)
	declarations map[int][]*Declaration
	// tracks whether ident has been forward declared
	declarationsTrack map[string]*Declaration
	// functions to be defined later
	Functions []FunctionDefinition
	// annotation stack
	annotationStack *stack.Stack[Annotation]
	// current module being built
	module *Module
	// tokens scanned during lexical analysis
	Tokens []token.Token
	// current position in `Tokens` slice
	tokenPos int
	// errors, warnings, and logs during parsing
	messages []errors.ErrorMessage
	// controls whether comments should be dropped
	dropComments bool
	// set to true if parser wrote a terminal error to its messages
	panicking bool
	// set to true if parser is parsing type family
	isParsingFamily bool
	// source code
	source.SourceCode
	// symbol table
	Symbols *module.SymbolTable
	// expression re-parsing stack
	exprStack *stack.Stack[ExprNode]
	// function identifier holding stack
	infoStack *stack.Stack[info]
	// trait declarations
	traits map[string]TraitDefinition
	// type declarations
	types map[string]ParameterizedTypeLike
	// type declarations
	typeAliases map[string]TypeConstant
	// annotations used during symbol creation

}

// parser for expressions, holds additional flags
type expressionParser struct {
	*Parser
	// flag for whether, where applicable, newlines can appear in an expression
	allowNewlineDropping bool
}

// get next token and advance input
func (p *Parser) Advance() (tok token.Token) {
	tok = p.Peek()
	p.tokenPos++
	return tok
}

// returns the parser's current definition number and then increments the internal value for it
func (p *Parser) AdvanceDefNumber() (definitionNumber int) {
	definitionNumber = p.definitionNumber
	p.definitionNumber++
	return
}

// get next token but only advance input if next token has the type `typeCondition`.
//
// If the next token has that type, then truthy == true; otherwise, truthy == false
//
// The token stream is advanced if and only if truthy == true. Another way to think about this is
// a (*Parser).Peek followed by a condition advance where the condition is whether Peek returns a
// token with type `typeCondition`
func (p *Parser) ConditionalAdvance(typeCondition token.Type) (tok token.Token, truthy bool) {
	truthy = p.Peek().Type == typeCondition
	if truthy {
		tok = p.Peek()
		if tok.Type != token.EndOfTokens {
			p.tokenPos++
		}
	}
	return
}

// clears parser's message buffer and returns all messages
func (parser *Parser) FlushMessages() (messages []errors.ErrorMessage) {
	messages = parser.messages
	parser.messages = []errors.ErrorMessage{}
	return messages
}

// composes the receiver inside an expression parser wrapper
func (parser *Parser) ForExpr() expressionParser {
	return expressionParser{parser, true}
}

// composes the receiver inside a pattern parser wrapper
func (parser *Parser) ForPattern() expressionParser {
	return expressionParser{parser, false}
}

func DeclarationMake(ident Ident, ty TypeNode) (dec Declaration) {
	split := splitIdent(ident.Value)
	return Declaration{Split: split, Ident: ident, TypeNode: ty}
}

// declares identifier 'ident' with the type 'ty'
//
// fails if ident has already been declared
func (parser *Parser) Declare(annotations []Annotation, ident Ident, ty TypeNode) (dec *Declaration, ok bool) {
	var found bool
	if _, found = parser.declarationsTrack[ident.Value]; found {
		parser.error(IllegalRedeclaration)
		return
	}

	// create forward declaration
	dec = new(Declaration)
	*dec = DeclarationMake(ident, ty)

	// add to tracking table
	parser.declarationsTrack[ident.Value] = dec

	// prepare for adding to declarations table
	numElem := len(dec.Split)
	var elems []*Declaration
	if elems, found = parser.declarations[numElem]; !found {
		elems = []*Declaration{}
	}
	elems = append(elems, dec)

	// add to table
	parser.declarations[numElem] = elems
	ok = true
	return
}

// returns parsed module and clears parsers internal module data
func (p *Parser) GetModule() Module {
	if p.module == nil {
		panic("bug: no module")
	}

	module := *p.module
	p.module = nil
	return module
}

// initializes a returns new parser
//
// Deprecated: use InitParser instead, this function will be removed soon
func Init(path string, positions []int, tokens []token.Token) *Parser {
	return &Parser{
		SourceCode: source.SourceCode{
			Path:           source.FilePath(path),
			PositionRanges: positions,
		},
		Tokens:            tokens,
		declarations:      make(map[int][]*Declaration),
		declarationsTrack: make(map[string]*Declaration),
		dropComments:      true,
		messages:          []errors.ErrorMessage{},
	}
}

// initializes parser
//
// `sourceCode` should be source code that was used in the creation of `tokens`
func InitParser(sourceCode source.SourceCode, tokens []token.Token) (parser *Parser) {
	parser = new(Parser)
	*parser = Parser{
		SourceCode:        sourceCode,
		Tokens:            tokens,
		declarations:      make(map[int][]*Declaration),
		declarationsTrack: make(map[string]*Declaration),
		annotationStack:   stack.NewStack[Annotation](8),
		exprStack:         stack.NewStack[ExprNode](8),
		dropComments:      true,
		messages:          []errors.ErrorMessage{},
	}
	return parser
}

func (parser *Parser) LookupDeclaration(ident Ident) (dec *Declaration, found bool) {
	dec, found = parser.declarationsTrack[ident.Value]
	return
}

// sets source code copy bytes
func (parser *Parser) SetSourceCode(src []byte) {
	parser.Source = src
}

// generates a unique variable name "@n" for some unique integer n >= 0
func (parser *Parser) UniqueId() string {
	n := parser.uniqueIdCounter
	parser.uniqueIdCounter++
	return fmt.Sprintf("@%d", n)
}

// true iff parser has recorded an error since the last time the errors have been reset
func (p *Parser) Panicking() bool { return p.panicking }

// returns next token but does not advance past it
func (p *Parser) Peek() token.Token {
	if p.tokenPos >= len(p.Tokens) {
		return endOfTokensToken()
	}

	return p.Tokens[p.tokenPos]
}

// sets value of dropComments
func (parser *Parser) SetDropComments(truthy bool) {
	parser.dropComments = truthy
}

// no-op when parser.tokenCounter != 0
func (parser *Parser) LoadCurrent() {
	if parser.tokenPos != 0 {
		return
	}

	parser.Advance() // set next
	parser.Advance() // current <- next, set next
}

// start optional parsing--returns defer-able function that restores previous option flag value
// func (parser *Parser) StartOptional() (deferEnd func()) {
// 	save := parser.optionalFlag
// 	parser.optionalFlag = true
// 	return func() { parser.optionalFlag = save }
// }

// // stops optional parsing--returns a defer-able function that restores previous option flag value
// func (parser *Parser) StopOptional() (deferEnd func()) {
// 	save := parser.optionalFlag
// 	parser.optionalFlag = false
// 	return func() { parser.optionalFlag = save }
// }

// adds a message to parser's internal messages slice
func (parser *Parser) addMessage(e errors.ErrorMessage) {
	parser.messages = append(parser.messages, e)
	parser.panicking = parser.panicking || e.IsFatal()
}

// returns an "End" token
func endOfTokensToken() token.Token {
	return token.Token{Type: token.EndOfTokens}
}

// returns declarations that matches `pat`
//
// if one doesn't exist, the second return value, found, is false
func (parser *Parser) findMatchingDeclaration(pat []PatternNode, decs []*Declaration) (dec *Declaration, found bool) {
	// search for matching declaration (if one exists)
	for _, dec = range decs {
		if found = SyntacticMatch(pat, *dec); found {
			return
		}
	}
	return
}

// TODO: rename function
// matches `pat` with a forward declarations stored w/in `parser`.
//
// if one doesn't exist, the second return value, found, is false
func (parser *Parser) forwardPatternMatch(pat []PatternNode) (dec *Declaration, found bool) {
	patternLen := len(pat)
	var decs []*Declaration
	if decs, found = parser.declarations[patternLen]; found {
		return parser.findMatchingDeclaration(pat, decs)
	}

	if patternLen <= 1 {
		return
	}

	// check if in 1-length
	if decs, found = parser.declarations[1]; found {
		return parser.findMatchingDeclaration(pat[:1], decs)
	}
	return
}

const applicationPrecedence uint8 = 10

// called whenever a function is seen, may call `apply` first and then `shift` and `apply` again, or just `shift`
func (parser *Parser) hold(ident Ident) (ok bool) {
	sym, found := parser.Symbols.Lookup(ident)
	if ok = found; !ok {
		parser.error2(UndefinedName, ident.Start, ident.End)
		return
	}

	if parser.infoStack.GetCount() > 0 {
		op, _ := parser.infoStack.Peek()
		applyFirst := op.precedence > sym.Precedence
		applyFirst = applyFirst || (!sym.RightAssoc() && op.precedence == sym.Precedence)
		if !applyFirst {
			parser.apply()
		}
	}

	info := info{
		arity:      sym.Arity,
		precedence: sym.Precedence,
		postfixed:  sym.Binding.Postfixed(),
		right:      sym.Binding.RightAssoc(),
	}
	app := Application{Elems: []ExprNode{ident}}
	parser.infoStack.Push(info)
	parser.shift(app)
	if info.right {
		parser.apply()
	}
	return // ok==true
}

func (parser *Parser) apply() (ok bool) {
	if ok = parser.infoStack.GetCount() > 0; !ok {
		parser.applyNoInfoReport()
		return
	}

	info, _ := parser.infoStack.Pop()
	info.arity-- // decrement arity (function application reduces arity by one)
	exprs, _ := parser.exprStack.MultiPop(2)
	var function Application
	var applicant ExprNode
	var fi, ai int // function index and application index respectively
	if info.postfixed {
		// let the operation be either `_?_` or `_?`:
		// if actually infix, then becomes prefix op
		// 	[ x ] [_?_] -> [ x ?_ ] (now a prefix op)
		// if actually postfix, then becomes non-function
		// 	[ x ] [_? ] -> [ x ?  ] (now a non-function (some kind of value))
		// either way, stack top will now be categorized as a prefix affixation

		// set to not postfixed (infixed is both pre- and post- fixed; thus, if not postfixed, then it
		// cannot be infixed either)
		info.postfixed = false
		fi, ai = 1, 0
	} else {
		fi, ai = 0, 1
	}

	function, ok = exprs[fi].(Application)
	applicant = exprs[ai]

	if !ok {
		start, end := exprs[fi].Pos()
		parser.error2(IllegalApplication, start, end)
		return
	}

	// apply a to f, (f a)
	function.Elems = append(function.Elems, applicant)

	if info.arity > 0 { // still accepting applicants?
		parser.infoStack.Push(info)
	} // else, just a non-function value now

	// regardless, push onto expression stack
	parser.exprStack.Push(function)
	return
}

// report issue related to trying to apply things when either nothing to apply or things cannot be applied
func (parser *Parser) applyNoInfoReport() {
	if parser.exprStack.GetCount() < 2 {
		panic("bug: apply called but expression stack is empty")
	}
	es, _ := parser.exprStack.MultiCheck(2)
	start, end := startEnd(es[0], es[1])
	parser.error2(IllegalApplication, start, end)
}

func (parser *Parser) shift(current ExprNode) {
	parser.exprStack.Push(current)
}

package parser

import "testing"

func TestGetToken(t *testing.T) {
	
}

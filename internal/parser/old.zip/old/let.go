// =================================================================================================
// Alex Peters - January 30, 2024
//
// Parses let-bindings
// =================================================================================================
package parser

import "github.com/petersalex27/yew/token"

// parses a let-binding
//
// example:
//
//	let x = 3 in x + x
func (parser expressionParser) parseLetBinding() (let LetBinding, ok bool) {
	var letToken token.Token
	if letToken, ok = parser.letToken(); !ok {
		return
	}
	let.Start = letToken.Start

	let.Bindings = []FunctionDefinition{}
	parser.dropDroppables()
	for again := true; again; {
		var binding FunctionDefinition
		binding, ok = parser.parseLetBindingIteration()
		if !ok {
			return
		}
		let.Bindings = append(let.Bindings, binding)
		parser.dropDroppables()
		// will throw error on any invalid token next iteration; so, checking for just end condition is fine
		again = parser.Peek().Type != token.In 
	}

	// ig assign End to the value of the 'in' token??
	// assigning it to the end of the expression it binds is likely too much information??
	let.End = parser.Advance().End

	let.Bound, ok = parser.parseExpression()
	return
}

func (parser expressionParser) parseLetBindingIteration() (binding FunctionDefinition, ok bool) {
	var ident Ident
	if ident, ok = parser.parseFunctionName(); !ok {
		return
	}
	return parser.parseFunctionWithName(ident)
}

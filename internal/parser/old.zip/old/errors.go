// =================================================================================================
// Alex Peters - January 24, 2024
// =================================================================================================

package parser

import (
	"fmt"

	"github.com/petersalex27/yew/errors"
	"github.com/petersalex27/yew/source"
	"github.com/petersalex27/yew/token"
)

const (
	// = "expected" ==================================================================================
	ExpectedBinding         string = "expected lambda binding '_->_'"
	ExpectedEqual           string = "expected assignment"
	ExpectedIdentifier      string = "expected identifier"
	ExpectedBigIdentifier   string = "expected \"big\" identifier"
	ExpectedIn              string = "expected 'in'"
	ExpectedModule          string = "expected 'module'"
	ExpectedName            string = "expected name"
	ExpectedRBrace          string = "expected '}'"
	ExpectedRBracket        string = "expected ']'"
	ExpectedRParen          string = "expected ')'"
	ExpectedThickArrow      string = "expected '=>'"
	ExpectedType            string = "expected type"
	ExpectedTypeApplication string = "expected type application"
	ExpectedTypeJudgment    string = "expected type judgment"
	ExpectedVariable        string = "expected variable"
	ExpectedWhere           string = "expected 'where'"

	// = "illegal" ===================================================================================
	IllegalApplication         string = "illegal application"
	IllegalEnclosedTypeFamily  string = "illegal type family, type family enclosed by type family"
	IllegalImplicitDeclaration string = "illegal declaration, implicit declaration of affixed identifier"
	IllegalImport              string = "illegal import, empty"
	IllegalPattern             string = "illegal pattern, expected initial identifier"
	IllegalRedeclaration       string = "illegal redeclaration"
	IllegalReimport            string = "illegal import, multiply declared module"
	IllegalTraitNoParams       string = "illegal trait, no type parameters"
	IllegalTraitRedeclaration  string = "illegal trait redeclaration"
	IllegalTupleType           string = "illegal tuple type, must be an n-tuple where n > 1"
	IllegalTypeRedeclaration   string = "illegal type redeclaration"
	IllegalUse                 string = "illegal use-import, empty"
	IllegalWhere               string = "illegal 'where'"

	// = "invalid" ===================================================================================
	InvalidListElementType string = "invalid list type, no element type"
	InvalidTypeIdentifier  string = "invalid type identifier"

	// TODO: better message??
	UnusedContext string = "unreferenced context"

	// = "unexpected" ================================================================================
	UnexpectedEOF   string = "unexpected end of file"
	UnexpectedToken string = "unexpected token"
)

const (
	UndefinedName string = "undefined name"
	UndefinedType string = "undefined type"

	RedefAlias    string = "illegal definition, type alias redefined"
	RedefFunction string = "illegal definition, function redefined"
	RedefType     string = "illegal definition, type redefined"
	RedefTypeCons string = "illegal definition, type constructor redefined"
)

// (token, "expected" error message) pairs
var expectMap = map[token.Type]string{
	token.Arrow:      ExpectedBinding,
	token.Equal:      ExpectedEqual,
	token.Id:         ExpectedIdentifier,
	token.Module:     ExpectedModule,
	token.RightParen: ExpectedRParen,
	token.Where:      ExpectedWhere,
	token.Colon:      ExpectedType,
}

// returns appropriate "expected X" where X is the expected token with type `expect`.
//
// if there's no appropriate "expected X" message for the given type, then `UnexpectedToken` is
// returned
func getExpectMessage(expect token.Type) (errorMessage string) {
	if errorMessage, found := expectMap[expect]; found {
		return errorMessage
	}

	return UnexpectedToken
}

// creates a syntax error from the arguments
func makeNameError(msg string, path source.PathSpec, line, lineEnd, start, end int) errors.ErrorMessage {
	e := errors.MakeError("Name", msg, line, lineEnd, start, end)
	e.SourceName = path.String()
	return e
}

// creates a syntax error from the arguments
func makeSyntaxError(msg string, path source.PathSpec, line, lineEnd, start, end int) errors.ErrorMessage {
	e := errors.MakeError("Syntax", msg, line, lineEnd, start, end)
	e.SourceName = path.String()
	return e
}

// creates a syntax error from the arguments
func makeSyntaxWarning(msg string, path source.PathSpec, line, lineEnd, start, end int) errors.ErrorMessage {
	e := errors.MakeWarning("Syntax", msg, line, lineEnd, start, end)
	e.SourceName = path.String()
	return e
}

// adds a warning constructed using the arguments
func (parser *Parser) warning2(msg string, startPos, endPos int) {
	line1, line2, char1, char2 := parser.CalcLocationRange(startPos, endPos)
	w := makeSyntaxWarning(msg, parser.Path, line1, line2, char1, char2)
	w.Message += parser.Window(startPos, endPos) + "\n"
	parser.addMessage(w)
}

// adds an error constructed using the arguments
func (parser *Parser) error2(msg string, startPos, endPos int) {
	line1, line2, char1, char2 := parser.CalcLocationRange(startPos, endPos)
	e := makeSyntaxError(msg, parser.Path, line1, line2, char1, char2)
	e.Message = fmt.Sprintf("%s\n%s\n", e.Message, parser.Window(startPos, endPos))
	parser.addMessage(e)
}

// adds an error constructed using parser's data and the message string passed as an argument
func (parser *Parser) error(msg string) {
	start, end := parser.Peek().Start, parser.Peek().End
	line1, line2, char1, char2 := parser.CalcLocationRange(start, end)
	e := makeSyntaxError(msg, parser.Path, line1, line2, char1, char2)
	e.Message = fmt.Sprintf("%s\n%s\n", e.Message, parser.Window(start, end))
	parser.addMessage(e)
}

func (parser *Parser) nameError2(msg string, startPos, endPos int) {
	line1, line2, char1, char2 := parser.CalcLocationRange(startPos, endPos)
	e := makeNameError(msg, parser.Path, line1, line2, char1, char2)
	e.Message = fmt.Sprintf("%s\n%s\n", e.Message, parser.Window(startPos, endPos))
	parser.addMessage(e)
}

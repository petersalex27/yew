// =================================================================================================
// Alex Peters - January 27, 2024
// =================================================================================================
package parser

import "testing"

func TestSplitIdent(t *testing.T) {
	tests := []struct{
		ident string
		expected []string
	}{
		{
			ident: "if_then_else_",
			expected: []string{"if", "_", "then", "_", "else", "_"},
		},
		{
			ident: "_+_",
			expected: []string{"_", "+", "_"},
		},
		{
			ident: "__",
			expected: []string{"_", "_"},
		},
		{
			ident: "[_]",
			expected: []string{"[", "_", "]"},
		},
		{
			ident: "map",
			expected: []string{"map"},
		},
		{
			ident: "_",
			expected: []string{"_"},
		},
		{
			ident: "",
			expected: []string{},
		},
		{
			ident: "_ _",
			expected: []string{"_", " ", "_"},
		},
	}

	for _, test := range tests {
		actual := splitIdent(test.ident)
		if len(actual) != len(test.expected) {
			t.Fatalf("unexpected length (%v): got %v", len(test.expected), len(actual))
		}

		for i := range test.expected {
			if test.expected[i] != actual[i] {
				t.Fatalf("unexpected element at index %d (\"%s\"): got \"%s\"", i, test.expected[i], actual[i])
			}
		}
	}
}
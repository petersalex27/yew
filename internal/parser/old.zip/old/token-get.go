// =================================================================================================
// Alex Peters - January 30, 2024
//
// token retrieval and error reporting
// =================================================================================================
package parser

import (
	"github.com/petersalex27/yew/token"
)

// gets annotation token
func (parser *Parser) annotationToken() (annot token.Token, ok bool) {
	return parser.getToken(token.At, UnexpectedToken)
}

// gets '->' token (for types). This method differs from `bindingArrowToken` just by the error
// reported; the error here is more generic: "unexpected token"
func (parser *Parser) arrowToken() (arrow token.Token, ok bool) {
	return parser.getToken(token.Arrow, UnexpectedToken)
}

// gets backslash token '\'
func (parser *Parser) backslashToken() (token.Token, bool) {
	return parser.getToken(token.Backslash, UnexpectedToken)
}

// gets bar token '|'
func (parser *Parser) barToken() (bar token.Token, ok bool) {
	return parser.getToken(token.Bar, UnexpectedToken)
}

// gets '->' token
func (parser *Parser) bindingArrowToken() (arrow token.Token, ok bool) {
	return parser.getToken(token.Arrow, ExpectedBinding)
}

// gets capital id token, not node
func (parser *Parser) capIdToken() (capId token.Token, ok bool) {
	return parser.getToken(token.CapId, ExpectedBigIdentifier)
}

// gets ':' token
func (parser *Parser) colonToken() (colon token.Token, ok bool) {
	return parser.getToken(token.Colon, ExpectedTypeJudgment)
}

// gets 'end' keyword token
func (parser *Parser) endToken() (end token.Token, ok bool) {
	return parser.getToken(token.End, UnexpectedToken)
}

// gets '=' token
func (parser *Parser) equalToken() (eq token.Token, ok bool) {
	return parser.getToken(token.Equal, ExpectedEqual)
}

// gets a token with token type `ty` else reports an error with the message `errorMessage` when no
// token is found.
//
// ok == false if and only if function fails
func (parser *Parser) getToken(ty token.Type, errorMessage string) (tok token.Token, ok bool) {
	tok, ok = parser.ConditionalAdvance(ty)
	if !ok {
		parser.error(errorMessage)
	}
	return
}

// gets id token, not node
func (parser *Parser) idToken() (idTok token.Token, ok bool) {
	return parser.getToken(token.Id, ExpectedIdentifier)
}

// gets 'import' token
func (parser *Parser) importToken() (token.Token, bool) {
	return parser.getToken(token.Import, UnexpectedToken)
}

// gets 'in' token
func (parser *Parser) inToken() (in token.Token, ok bool) {
	return parser.getToken(token.In, ExpectedIn)
}

// gets left paren
func (parser *Parser) leftParen() (lparen token.Token, ok bool) {
	return parser.getToken(token.LeftParen, UnexpectedToken)
}

// gets 'let' token
func (parser *Parser) letToken() (let token.Token, ok bool) {
	return parser.getToken(token.Let, UnexpectedToken)
}

// parses 'module' keyword token
func (parser *Parser) moduleToken() (tok token.Token, ok bool) {
	return parser.getToken(token.Module, ExpectedModule)
}

// parses right brace token '}'
func (parser *Parser) rightBraceToken() (rbrace token.Token, ok bool) {
	return parser.getToken(token.RightBrace, ExpectedRBrace)
}

// parses right bracket token ']'
func (parser *Parser) rightBracketToken() (rbrack token.Token, ok bool) {
	return parser.getToken(token.RightBracket, ExpectedRBracket)
}

// parses right parenthesis token ')'
func (parser *Parser) rightParenToken() (rparen token.Token, ok bool) {
	return parser.getToken(token.RightParen, ExpectedRParen)
}

// gets '=>' token
func (parser *Parser) thickArrowToken() (bigArrow token.Token, ok bool) {
	return parser.getToken(token.ThickArrow, ExpectedThickArrow)
}

// gets import token
func (parser *Parser) useToken() (token.Token, bool) {
	return parser.getToken(token.Use, UnexpectedToken)
}

// parses an alpha-numeric id token
func (parser *Parser) variableIdToken() (v token.Token, ok bool) {
	v, ok = parser.idToken()
	ok = ok && isAlphaNumericId(v)
	return
}

// parses 'where' keyword token
func (parser *Parser) whereToken() (token.Token, bool) {
	return parser.getToken(token.Where, ExpectedWhere)
}

package parser

import (
	"testing"

	"github.com/petersalex27/yew/token"
)

// test tokens
var tt_0 = token.Token{Value: "test_token_0", Type: 0, Start: 0, End: 1}
var tt_1 = token.Token{Value: "test_token_1", Type: 1, Start: 2, End: 3}
var tt_2 = token.Token{Value: "test_token_2", Type: 2, Start: 4, End: 5}
var tt_3 = token.Token{Value: "test_token_3", Type: 3, Start: 6, End: 7}
var tt_4 = token.Token{Value: "test_token_4", Type: 4, Start: 8, End: 9}

func TestPeek(t *testing.T) {
	tests := []struct {
		tokens  []token.Token
		counter int
		expect  token.Token
	}{
		{
			tokens:  []token.Token{tt_0},
			counter: 0,
			expect:  tt_0,
		},
		{
			tokens:  []token.Token{tt_0},
			counter: 1,
			expect:  endOfTokensToken(),
		},
		{
			tokens:  []token.Token{},
			counter: 0,
			expect:  endOfTokensToken(),
		},
		{
			tokens:  []token.Token{},
			counter: 1,
			expect:  endOfTokensToken(),
		},
		{
			tokens:  []token.Token{tt_0, tt_1, tt_2},
			counter: 1,
			expect:  tt_1,
		},
		{
			tokens:  []token.Token{tt_0, tt_1, tt_2},
			counter: 2,
			expect:  tt_2,
		},
	}

	for _, test := range tests {
		pos := []int{100} // 100 is just some number bigger than any of the positions in the tokens
		parser := Init("", pos, test.tokens)
		parser.tokenPos = test.counter

		actual := parser.Peek()
		if actual != test.expect {
			t.Fatalf("unexpected token (%v): got %v", test.expect, actual)
		}
	}
}

func TestAdvance(t *testing.T) {
	tests := []struct {
		tokens  []token.Token
		counter int
		expect  token.Token
	}{
		{
			tokens:  []token.Token{tt_0},
			counter: 0,
			expect:  tt_0,
		},
		{
			tokens:  []token.Token{tt_0},
			counter: 1,
			expect:  endOfTokensToken(),
		},
		{
			tokens:  []token.Token{},
			counter: 0,
			expect:  endOfTokensToken(),
		},
		{
			tokens:  []token.Token{},
			counter: 1,
			expect:  endOfTokensToken(),
		},
		{
			tokens:  []token.Token{tt_0, tt_1, tt_2},
			counter: 1,
			expect:  tt_1,
		},
		{
			tokens:  []token.Token{tt_0, tt_1, tt_2},
			counter: 2,
			expect:  tt_2,
		},
	}

	for _, test := range tests {
		pos := []int{100} // 100 is just some number bigger than any of the positions in the tokens
		parser := Init("", pos, test.tokens)
		parser.tokenPos = test.counter

		actual := parser.Advance()
		if actual != test.expect {
			t.Fatalf("unexpected token (%v): got %v", test.expect, actual)
		}
		if parser.tokenPos != test.counter+1 {
			t.Fatalf("unexpected tokenCounter (%d): got %d", test.counter+1, parser.tokenPos)
		}
	}
}

func TestConditionalAdvance(t *testing.T) {
	tests := []struct {
		tokens       []token.Token
		counter      int
		afterCounter int
		condition    token.Type
		expect       token.Token
		ok           bool
	}{
		{
			tokens:       []token.Token{tt_0},
			counter:      0,
			condition:    0,
			afterCounter: 1,
			expect:       tt_0,
			ok:           true,
		},
		{
			tokens:       []token.Token{tt_0},
			counter:      1,
			condition:    1,
			afterCounter: 1,
			expect:       token.Token{},
			ok:           false,
		},
		{
			tokens:       []token.Token{},
			counter:      0,
			condition:    0,
			afterCounter: 0,
			expect:       token.Token{},
			ok:           false,
		},
		{
			tokens:       []token.Token{},
			counter:      1,
			condition:    endOfTokensToken().Type,
			expect:       endOfTokensToken(),
			afterCounter: 1,
			ok:           true,
		},
	}

	for _, test := range tests {
		pos := []int{100} // 100 is just some number bigger than any of the positions in the tokens
		parser := Init("", pos, test.tokens)
		parser.tokenPos = test.counter

		actual, ok := parser.ConditionalAdvance(test.condition)
		if ok != test.ok {
			t.Fatalf("unexpected ok (%v): got %v", test.ok, ok)
		}
		if actual != test.expect {
			t.Fatalf("unexpected token (%v): got %v", test.expect, actual)
		}
		if parser.tokenPos != test.afterCounter {
			t.Fatalf("unexpected tokenCounter (%d): got %d", test.afterCounter, parser.tokenPos)
		}
	}
}

// =================================================================================================
// Alex Peters - January 31, 2024
// =================================================================================================
package parser

import (
	"github.com/petersalex27/yew/common"
	"github.com/petersalex27/yew/token"
)

func (parser *Parser) ImportOrUseNext() (next token.Type, again bool) {
	next = parser.Peek().Type
	again = next == token.Import || next == token.Use
	return
}

func (p *Parser) parseModuleImport(im *Import, atLeastOnce bool) (_ bool, ok bool) {
	var imTmp Import
	imTmp, ok = p.parseImport()
	if !ok {
		return
	}

	if atLeastOnce {
		ok = p.mergeImports(im, imTmp)
		if !ok {
			return
		}
	} else {
		atLeastOnce = true
		*im = imTmp
	}
	return atLeastOnce, ok
}

func (p *Parser) parseModuleUse(use *Use, atLeastOnce bool) (_ bool, ok bool) {
	var useTmp Use
	useTmp, ok = p.parseUse()
	if !ok {
		return
	}

	if atLeastOnce {
		ok = p.mergeUses(use, useTmp)
		if !ok {
			return
		}
	} else {
		atLeastOnce = true
		*use = useTmp
	}
	return atLeastOnce, ok
}

// creates and initializes a new module
func newModule(im Import, use Use, start int, name token.Token) (module *Module) {
	const initialCapacity int = 32 // beyond being a power of two, 32 is an arbitrary choice

	module = new(Module)
	// initialize module data
	module.Import, module.Use = im, use
	module.ModuleName = name
	module.Start = start
	module.Definitions = common.MakeTable[token.Token, []DefinitionNode](initialCapacity)
	return
}

func (p *Parser) BuildModule() (ok bool) {
	p.dropDroppables()

	var im Import
	var use Use
	importedAtLeastOnce := false
	useAtLeastOnce := false
	ok = true
	next, again := p.ImportOrUseNext()
	for ; again; next, again = p.ImportOrUseNext() {
		switch next {
		case token.Import:
			importedAtLeastOnce, ok = p.parseModuleImport(&im, importedAtLeastOnce)
		case token.Use:
			useAtLeastOnce, ok = p.parseModuleUse(&use, useAtLeastOnce)
		default:
			panic("bug: next token not correctly validated")
		}

		if !ok {
			return
		}

		// maybe another import? e.g.,
		//	import
		//		g = graphics
		//	in import
		//		math
		//	in module m where ...
	}

	var moduleToken, name, endToken token.Token
	p.dropDroppables()
	if moduleToken, ok = p.moduleToken(); !ok {
		return
	}
	start := moduleToken.Start

	if name, ok = p.variableIdToken(); !ok {
		return
	}

	p.dropDroppables()
	if _, ok = p.whereToken(); !ok {
		return
	}

	p.module = newModule(im, use, start, name)

	p.parseDefinitions()

	endToken, ok = p.endToken()
	p.module.End = endToken.End
	return
}

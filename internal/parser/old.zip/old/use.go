// =================================================================================================
// Alex Peters - January 26, 2024
// =================================================================================================
package parser

import (
	"github.com/petersalex27/yew/common"
	"github.com/petersalex27/yew/token"
)


// returns true iff there's nothing to import
func (use Use) IsEmpty() bool {
	return use.Table == nil
}

// attempts to merge two use-imports. Fails, returning false, if there is a conflict when merging.
//
// example:
//
//	use -- dest
//		this
//		that
//	in use -- src
//		this -- conflict!!
//	in ...
//
// dest and src try to import the same thing, then IllegalReimport is reported and
// false is returned
func (parser *Parser) mergeUses(dest *Use, src Use) (ok bool) {
	for _, importPair := range src.All() {
		id, lookup := importPair.Key, importPair.Value
		if ok = parser.mapUniqueId(dest.Table, id, lookup); !ok {
			return
		}
	}
	return
}

// parses 'use' through 'in'
func (parser *Parser) parseUse() (use Use, ok bool) {
	var useKeyword token.Token
	if useKeyword, ok = parser.useToken(); !ok {
		return
	}
	use.Start = useKeyword.Start

	parser.dropDroppables()
	ok = parser.Peek().Type == token.Id
	if !ok {
		parser.error(IllegalUse)
		return
	}

	// choice of 4 for two reasons
	//	- small power of two
	// 	- assumption that there won't be many use-imports (since, generally, this is a bad idea)
	const initialCap int = 4
	use.Table = common.MakeTable[token.Token, token.Token](initialCap)

	for again := true; again; {
		var lookup token.Token
		lookup, ok = parser.variableIdToken()
		if !ok {
			return
		}

		parser.mapUniqueId(use.Table, lookup, lookup)
		parser.dropDroppables()
		again = parser.Peek().Type == token.Id
	}

	var in token.Token
	if in, ok = parser.inToken(); ok {
		use.End = in.End
	}
	return
}

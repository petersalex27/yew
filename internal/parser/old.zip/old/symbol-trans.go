// =================================================================================================
// Alex Peters - February 06, 2024
//
// Translating from ast node to module symbol
// =================================================================================================
package parser

import (
	"github.com/petersalex27/yew/module"
	"github.com/petersalex27/yew/types"
)

// creates a type symbol from a type definition
func SymbolizeType(typ ParameterizedTypeLike) module.TypeSymbol {
	name := module.TypeConstant(typ.Name)
	params := make([]types.Variable, len(typ.Params))
	for i, p := range typ.Params {
		params[i] = types.Variable(p.String())
	}
	return module.MakeType(name, params)
}

func (def TypeDefinition) SymbolizeConstructors(typ module.TypeSymbol) (cons []module.ConstructorSymbol) {
	cons = make([]module.ConstructorSymbol, len(def.Constructors))
	for i, con := range def.Constructors {
		cons[i] = module.MakeConstructorSymbol(typ.Application, con.Name.String(), ToTypes(con.Params))
	}
	return
}

func ToTypes(tys []TypeNode) []types.Monotype {
	out := make([]types.Monotype, len(tys))
	for i, ty := range tys {
		out[i] = ty.ToType()
	}
	return out
}
